/*----------------------------------------
* Depertamento de Informática - UFV
* Charles Abreu Santana - Mat: 87858
* Ultima modificação: 30/05/2016
*-----------------------------------------*/
/*
* Organiza um dataset de grafos em uma tabela
* A tabela conta os tipos de interacoes que cada grafo possui.
*/

#include<iostream>
#include<fstream>
#include<stdio.h>
#include<string>
#include <map>
#include <utility>
#include <stdlib.h>
#include<vector>
//#include<sstream>
using namespace std;
typedef vector <string> Grafo;

bool isIn(Grafo s, string str);
pair<int,string> splitAtonType(string line);
vector <Grafo> getDataSet(string dataset, map <int, string> mapeamento);
string getLabel(int numero, map <int, string> mapeamento);
map <int, string> getMapLabel(string rotulos);
vector <string> getLabelList(vector <Grafo> dataSet);
void createTable(vector <Grafo> graphDataSet, vector <string> labelList, string outDir);
void imprimeRotulos(map <int, string> mapeamento);
void imprimeLabelList(vector <string> vec);
vector <string> getMultiLabelList(vector <Grafo> graphDataSet);
vector <string> splitString(string str, char sep);
void createMultiLabelTable(vector <Grafo> graphDataSet, vector <string> labelList, string outDir);
vector <string> particoes(Grafo g);
int isInInt(Grafo s, string str);

int main(int argc, char* argv[]){

    if(argc == 1){
        cout<<"Entre com o nome do arquivo como parâmetro!"<<endl;
        return 0;
    }
    string dataset = argv[1]; //dataset com os grafos (arquivo .gsp)
    string rotulos = argv[2]; //arquivo com o mapeamento dos rotulos dos vertices
    int tipo = atoi(argv[3]); //Tipo de execucao (1 = Combinado ou 0 = particionado)

    map <int,string> mapeamento = getMapLabel(rotulos);//Mapeamento com numero/rotulo
    vector <Grafo> graphDataSet = getDataSet(dataset, mapeamento);//Vetor com todos os grafos
    if(tipo == 0 ){ //Particionado
        vector <string> labelList = getMultiLabelList(graphDataSet);//Lista de combinacoes entre rotulos dos vertices
        createMultiLabelTable(graphDataSet, labelList, "outDir/");
    } else if (tipo == 1){//Combinado
        vector <string> labelList = getLabelList(graphDataSet);//Lista de combinacoes entre rotulos dos vertices
        createTable(graphDataSet, labelList, "outDir/");
    }

    //imprimeLabelList(labelList);
    //imprimeRotulos(mapeamento);
}

bool isIn(Grafo s, string str){
    if(s.empty()) return false;
    for(int i=0; i < s.size(); i++){
        if(s[i].compare(str) == 0) return true;
    }
    return false;
}//Fim IsIn

int isInInt(Grafo s, string str){
    int contador = 0;
    if(s.empty()) return 0;
    for(int i=0; i < s.size(); i++){
        if(s[i].compare(str) == 0) contador ++;
    }
    return contador;
}//Fim IsIn

pair<int, string> splitAtonType(string line){
	pair <int, string> p;
	string type = "";
	int numType, positionDelimiter = 0;

	for(int i = 0; i < line.size(); i++){
		if(line[i] == ';') break;
		type += line[i];
		positionDelimiter ++;
	}
	string numero = line.substr(positionDelimiter+1, (line.size()-positionDelimiter + 1));
	numType = atoi(numero.c_str());
	p = make_pair(numType, type);
	return p;

}

string getLabel(int numero, map <int, string> mapeamento){
    int num = numero;
    string rotulo = "";
    int contador = 2;

    while(num != 1){
        if(num%contador == 0){
            if(rotulo.compare("") != 0) rotulo += "/";
            rotulo += mapeamento[contador];
            num = num/contador;
        } else{
            contador++;
        }
    }

    return rotulo;
}

vector <Grafo> getDataSet(string dataset, map <int, string> mapeamento){
    vector <Grafo> graphDataSet;//Vetor com todos os grafos
    ifstream in_dataSet(dataset.c_str());
    char tag;
    int rot, numero;
    in_dataSet >> tag;
    while(!in_dataSet.eof()){
        if((tag == 't') || (tag == '#'))    {
            Grafo g; //Cria um grafo
            in_dataSet >> tag;
            in_dataSet >> numero;
            //cout << "Grafo: "<< numero << endl;
            vector <int> rotulosVertices;
            in_dataSet >> tag;
            //Ate encontrar o proximo "e"
            while((tag == 'v') && (!in_dataSet.eof())){
                in_dataSet >> rot;
                in_dataSet >> rot;
                rotulosVertices.push_back(rot);
                //cout << "Rotulo: "<<rot <<endl;
                in_dataSet >> tag;
            }
            //cout << tag <<endl;
            //Ate encontrar o proximo "t"
            while((tag == 'e') && (!in_dataSet.eof())){
                int v1, v2;
                in_dataSet >> v1;
                in_dataSet >> v2;
                in_dataSet >> rot;
                string str;
                if(rotulosVertices[v1] < rotulosVertices[v2]){
                    str = getLabel(rotulosVertices[v1], mapeamento) + ":" + getLabel(rotulosVertices[v2], mapeamento);
                } else {
                    str = getLabel(rotulosVertices[v2], mapeamento) + ":" + getLabel(rotulosVertices[v1], mapeamento);
                }

                //cout<< "Aresta "<<p2.first <<" - "<<p2.second<<endl;
                g.push_back(str);

                in_dataSet >> tag;
            }
            graphDataSet.push_back(g);
        }
        //in_dataSet >> tag;
    }
    in_dataSet.close();
    return graphDataSet;
}

map <int, string> getMapLabel(string rotulos){
    map <int,string> mapeamento;

    ifstream in_rotulos(rotulos.c_str());
    string linha;

    in_rotulos >> linha;
    //Percorrre arquivo com o mapeamento dos rotulos nome/numero
    while(!in_rotulos.eof()){
        pair <int, string> p;
        p = splitAtonType(linha);
        mapeamento.insert(p);
        in_rotulos >> linha;
    }//Fim do while
    in_rotulos.close();

    return mapeamento;
}

vector <string> getLabelList(vector <Grafo> graphDataSet){
    map <string, int> possibleLabels;
    vector <string> labelList;

    for(int i =0; i<graphDataSet.size(); i++){
        for(int j = 0; j<graphDataSet[i].size(); j++){
            string lab = graphDataSet[i][j];
            possibleLabels.insert(pair <string, int> (lab, 0));
        }
    }

    map <string, int>::iterator it;
	for( it = possibleLabels.begin(); it != possibleLabels.end(); it++){
        labelList.push_back(it->first);
	}

    return labelList;
}

vector <string> getMultiLabelList(vector <Grafo> graphDataSet){
    map <string, int> possibleLabels;
    vector <string> labelList;

    for(int i =0; i<graphDataSet.size(); i++){
        for(int j = 0; j<graphDataSet[i].size(); j++){
            vector <string> aresta = splitString(graphDataSet[i][j], ':');
            vector <string> vertice1 = splitString(aresta[0], '/');
            vector <string> vertice2 = splitString(aresta[1], '/');
            for(int k = 0; k < vertice1.size(); k++){
                for(int l = 0; l < vertice2.size(); l++){
                    string lab;
                    if(vertice1[k] < vertice2[l]){
                        lab = vertice1[k] + ":" + vertice2[l];
                    } else{
                        lab = vertice2[l] + ":" + vertice1[k];
                    }
                    possibleLabels.insert(pair <string, int> (lab, 0));
                }
            }
        }
    }

    map <string, int>::iterator it;
	for( it = possibleLabels.begin(); it != possibleLabels.end(); it++){
        labelList.push_back(it->first);
	}

    return labelList;
}

void createTable(vector <Grafo> graphDataSet, vector <string> labelList, string outDir){
    string nomeArquivo = outDir + "out.csv";
    ofstream outTable(nomeArquivo.c_str());
    ofstream firstColumn("outDir/firstColumn");

    //outTable <<"#";
    for(int i =0; i<labelList.size(); i++){
        //if(i != 0 ) outTable << ";";
        outTable << "," << labelList[i];
    }
    outTable <<"\n";

    int table [graphDataSet.size()][labelList.size()];
    for(int i =0; i < graphDataSet.size(); i++){
        for(int j=0; j<labelList.size(); j++){
            table[i][j] = 0;
        }
    }

    for(int i =0; i<graphDataSet.size(); i++){
        for(int j=0; j<labelList.size(); j++){
            table[i][j] = isInInt(graphDataSet[i], labelList[j]);
        }
    }

    for(int i =0; i<graphDataSet.size(); i++){
        firstColumn << i <<"\n";
        outTable << i;
        for(int j=0; j<labelList.size(); j++){
            outTable << "," << table[i][j];
        }
        outTable<<"\n";
    }
    outTable.close();
    firstColumn.close();
}

void createMultiLabelTable(vector <Grafo> graphDataSet, vector <string> labelList, string outDir){
    string nomeArquivo = outDir + "out.csv";
    ofstream outTable(nomeArquivo.c_str());
    ofstream firstColumn("outDir/firstColumn");

    //outTable <<"";
    for(int i =0; i<labelList.size(); i++){
        //if(i != 0 ) outTable << ";";
        outTable << "," << labelList[i];
    }
    outTable <<"\n";

    int table [graphDataSet.size()][labelList.size()];

    for(int i =0; i < graphDataSet.size(); i++){
        for(int j=0; j<labelList.size(); j++){
            table[i][j] = 0;
        }
    }

    for(int i =0; i < graphDataSet.size(); i++){
        vector <string> graphLabelList = particoes(graphDataSet[i]);
        for(int j=0; j<labelList.size(); j++){
            table[i][j] = isInInt(graphLabelList, labelList[j]);
        }
    }

    for(int i =0; i<graphDataSet.size(); i++){
        outTable << i;
        firstColumn << i <<"\n";
        for(int j=0; j<labelList.size(); j++){
            outTable << "," << table[i][j];
        }
        outTable<<"\n";
    }
    outTable.close();
    firstColumn.close();
}

void imprimeRotulos(map <int, string> mapeamento){
    map <int, string>::iterator it;
	for( it = mapeamento.begin(); it != mapeamento.end(); it++){
        cout<< it->first <<" - "<< it->second <<endl;
	}
 }

 void imprimeLabelList(vector <string> vec){
    for(int i=0; i<vec.size(); i++){
        cout<<vec[i]<<endl;
    }
 }

//Particiona uma string str usando como referencia o separador sep
//Retorna um vector de string com as particoes
vector <string> splitString(string str, char sep){
    string aux;
    vector <string> splits;
    for(int i =0; i<str.size(); i++){
        if(str[i] != sep){
            aux += str[i];
        }else{//Quando encontra o separador cria uma nova particao
            splits.push_back(aux);
            aux = "";
        }
        //Pega ultima particao
        if(i == (str.size()-1)){
            splits.push_back(aux);
        }
    }//Fim do for
    return splits;
}//Fim de splitString

vector <string> particoes(Grafo g){
    vector <string> labels;
    for(int i =0; i<g.size(); i++){
        vector <string> aresta = splitString(g[i], ':');
        vector <string> vertice1 = splitString(aresta[0], '/');
        vector <string> vertice2 = splitString(aresta[1], '/');
        for(int k = 0; k < vertice1.size(); k++){
            for(int l = 0; l < vertice2.size(); l++){
                string lab;
                if(vertice1[k] < vertice2[l]){
                    lab = vertice1[k] + ":" + vertice2[l];
                } else{
                    lab = vertice2[l] + ":" + vertice1[k];
                }
                    labels.push_back(lab);
                }
            }
    }
    return labels;
}
