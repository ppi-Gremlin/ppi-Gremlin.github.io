#!/usr/bin/perl -w 

# *******************************************************
# *		Grupo de Bioinformatica Estrutural				*
# *		UFMG/DCC										*
# *   ----------------------------------------------	*
# *														*
# * Douglas Eduardo Valente Pires - dpires@dcc.ufmg.br	*
# * www.dcc.ufmg.br/~dpires								*
# * Ultima Modificacao :: 17/02/2012					*
# *   ----------------------------------------------	*
# * "With great power, comes great responsibility."		*
# *******************************************************

use strict;
use warnings;

#---------------------------------------------------------------------------------------------------
my $infile = $ARGV[0];			# Arquivo de entrada - lista de csvs
my $columnFile = $ARGV[1];		# Arquivo de entrada - primeira coluna (label com pdbid.cadeia)
# my ($infile, $firstColumFile) = @ARGV;
#---------------------------------------------------------------------------------------------------
if(scalar(@ARGV) != 2){
	print "#####################################################################\n";
	print " SINTAXE:\n\tperl coloca_cabecalho_csv.pl <in_csvs> <first_column_file>\n";
	print "#####################################################################\n";
	exit;
}
#---------------------------------------------------------------------------------------------------
open(INFILE,"<$infile") or die "$!Erro ao abrir: $infile\n";
my @list = <INFILE>;
close INFILE;


open (my $column, "<", $columnFile) or die "$!Erro ao abrir: $columnFile\n";
my @columnheader = <$column>;
close $column;


foreach my $file (@list){
	chomp($file);
	open(FILE,"<$file") or die "$!Erro ao abrir: $file\n";
	my @lines = <FILE>;
	close FILE;

	my @tokens = split(",", $lines[0]);
	open(OUT,">aewyerqouweahjewgahas") or die "$!Erro ao abrir: aewyerqouweahjewgahas\n";

	for(my $i=1; $i<scalar(@tokens)+1; $i++){ #	vamos ter que colocar cabecalho em +1 coluna
		print OUT "$i,";
	}
	print OUT "class\n";

	#########
	#	if tamanho do column header = tamanho do lines: escreve
	#	senão, dá mensagem de erro
	# colocar chomp no columnheader
	#########

	my $flag = 0;

	#print "@lines\n\n";
	#print "@columnheader\n";

	#print "scalar(@columnheader)\n";
	#print "scalar(@lines)\n";


	print "Tamanho: " . scalar(@lines). "\n";


	if (scalar(@columnheader) == scalar(@lines)) {

		for(my $j=0; $j<scalar(@columnheader); $j++){ #	percorrer as linhas colocando label (pdbid.cadeia) em cada uma
			
			# tem que arrumar, quero o indice j
			chomp($columnheader[$j]);
			print OUT $columnheader[$j] . "," . $lines[$j];
		}				
		$flag = 1;

	} else {
		print "Erro:numero de linhas da coluna 1 de label eh diferente do numero de linhas do arquivo\n";
		close OUT;
		system("rm aewyerqouweahjewgahas");
	}	

	close OUT;
	if ($flag ==1){
		system("mv aewyerqouweahjewgahas $file");
	}	
}



