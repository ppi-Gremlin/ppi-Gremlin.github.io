library(cluster);
library(fpc);
library(pvclust);
library(data.table);
library(mclust);

#setwd("/home/charles/Documentos/GraphMinig")

# *******************************************************
# *		Grupo de Bioinformatica Estrutural				*
# *		UFMG/DCC										*
# *   ----------------------------------------------	*
# *														*
# * Douglas Eduardo Valente Pires - dpires@dcc.ufmg.br	*
# * www.dcc.ufmg.br/~dpires								*
# * Ultima Modificacao :: 11/04/2011					*
# *   ----------------------------------------------	*
# *******************************************************

# ==================================================================================================
infile = read.table(file="infile")
infileList = as.vector(infile[,1])

for(k in 1:length(infileList)){
  tabelaCutoff = t(read.table(file=infileList[k],header=T,row.names=1,sep=","))
  
  numcolumns = (dim(tabelaCutoff)[1]-1)
  indiceclass = dim(tabelaCutoff)[1]
  
  vetorInt = as.integer(tabelaCutoff[1:numcolumns,])
  tabela = matrix(vetorInt,nrow=numcolumns,ncol=length(tabelaCutoff[1,]))
  
  # ***alterado por Sabrina
  nrow=numcolumns;
  ncol=length(tabelaCutoff[1,]);
  max = min(nrow, ncol, 100);
  # ***
  
  svd = svd(tabela,nv =max)
  svd_D = svd$d
  svd_V = svd$v
  svd_U = svd$u
  #browser();
  
  plotout = paste(infileList[k],".SV.png",sep="") 
  png(plotout); 
  plot(svd_D[1:length(svd_D)],ylab="")
  title("Singular Values")
  dev.off();
  
  
  for(aaa in seq(1,max,1)){
    outfile = paste(infileList[k],".",aaa,"D.csv",sep="")
    sink(outfile)
    if(aaa > 1){
      classify = (diag(svd_D[1:aaa]) %*% t(svd_V[,1:aaa]))
      for(i in 1:length(classify[1,])){
        cat(classify[,i],tabelaCutoff[indiceclass,i],sep=",")
        cat("\n")
      }
    }
    else{
      
      classify = svd_D[1] * t(svd_V[,1:aaa])
      for(i in 1:length(classify[1,])){
        cat(classify[,i],tabelaCutoff[indiceclass,i],sep=",")
        cat("\n")
      }
    }
    sink()
  }
}

