#-----------------------------------------------------------
# Desenvolvido por Sabrina de Azevedo Silveira 27/02/2015
# Universidade Federal de Viçosa (UFV)
#-----------------------------------------------------------

# entrada: lista de arquivos resultantes do SVD  (todos os cortes);
#setwd("/home/charles/Documentos/GraphMinig")
infile = read.table(file="infile")
infileList = as.vector(infile[,1])
library(cluster);
library(fpc);
library(pvclust);
library(data.table);
library(mclust);

numTotalCortesSVD = length(infileList);
asw = numeric(numTotalCortesSVD);
aswNumCluster = numeric(numTotalCortesSVD);
keepBestDim = NULL;
bestCluster = NULL;
infileBest = NULL;
keep = NULL;
keepLabels = NULL;
columnlabels = vector(mode="character", length=numTotalCortesSVD);

for(k in 1:length(infileList)){

	numDimSVD = sub(".*?\\.(\\d+)D\\.csv.*", "\\1", infileList[k]);	#	pego o numero de dimensoes do svd do nome do arquivo csv
	kSVD = strtoi(numDimSVD, 10L);

	tabela = read.table(file=infileList[k], sep=",", header=TRUE)	#	atençao para o cabeçalho
	keepLabels = tabela[,1]	
	rownames(tabela) = tabela[,1]					
	tabela = tabela[,-1]						#	tiro primeira coluna pois é label
	tabela = tabela[,-ncol(tabela)]					#	tiro ultima coluna pois é informacao ficticia de classe 



					
	columnlabels[[kSVD]] = paste("svd_", kSVD, sep="");
	#colnames(tabela)

	#-----------------------------------------------------------
	# Partitioning
	# K medoids clustering with the number of clusters estimated by optimum average silhouette width
	#-----------------------------------------------------------

	if(kSVD == 1){
		#tabela = t(tabela)
		kmedoids = pamk(tabela, 2:(length(tabela)-1), critout=FALSE);
	}else{
		kmedoids = pamk(tabela, 2:(nrow(tabela)-1), critout=FALSE);
	}


	# par(mfrow=c(1,2))
	# plot(kmedoids$pamobject)

	asw[[kSVD]] = kmedoids $ pamobject $ silinfo $ avg.width
	aswNumCluster[[kSVD]] = kmedoids $ nc
	outkmedoids = rbind(asw, aswNumCluster);
	columnlabels[[kSVD]] = paste("svd_", kSVD, sep="");


	keepBestDim = which.max(asw)
	if(kSVD == keepBestDim){					#	se eh o corte do SVD que deu melhor resultado até agora guarda
		bestcluster = kmedoids;
		infileBest = infileList[k];
	}

	#-----------------------------------------------------------
	# Hierarchical Agglomerative
	# Ward Hierarchical Clustering with Bootstrapped p values
	# tem paper
	#-----------------------------------------------------------

	#-----------------------------------------------------------
	# Model based
	# 
	# tem paper: http://www.jstatsoft.org/v18/i06/paper
	# https://www.stat.washington.edu/research/reports/2012/tr597.pdf
	#-----------------------------------------------------------
}

# imprime grafico
graficoKmed = paste(infileBest, ".", bestcluster $ nc, "C", ".kmed.png", sep="");
png(graficoKmed, width=900, height=600, units = "px");
par(mfrow=c(1,2));
plot(bestcluster $ pamobject)
dev.off();

# salva dados de saida em arquivo
filekmed = paste(infileBest, ".", bestcluster $ nc, "C", ".kmed.csv", sep="");
colnames(outkmedoids) = columnlabels;
write.table(outkmedoids, file = filekmed, sep = ",", quote = FALSE);

# salva o melhor grupo com as intancias e o grupo ao qual pertencem
fileOutClu = paste(infileBest, ".", bestcluster $ nc, "O", ".kmed.out", sep="");
outClu = data.frame(keepLabels, bestcluster$pamobject$cluster);
outCluOrdered = outClu[order(outClu$bestcluster.pamobject.cluster),];
write.table(outCluOrdered, file = fileOutClu, sep = ",", quote = FALSE, row.names = FALSE, col.names = FALSE);

# salva o melhor grupo com as intancias e o grupo ao qual pertencem
fileOutClu = paste("mapeamento.kmed.out", sep="");
outClu = data.frame(keepLabels, bestcluster$pamobject$cluster);
outCluOrdered = outClu[order(outClu$bestcluster.pamobject.cluster),];
write.table(outCluOrdered, file = fileOutClu, sep = ",", quote = FALSE, row.names = FALSE, col.names = FALSE);

