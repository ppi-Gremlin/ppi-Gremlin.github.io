/*------------------------------------------
* Depertamento de Informática - UFV
* Charles Abreu Santana - Mat: 87858
* Ultima modificação: 28/06/2016
*-------------------------------------------*/

//g++ -std=gnu++0x mapeamento.cpp -I/usr/local/igraph -L/usr/local/lib -ligraph -o mapeamento

#include<iostream>
#include<fstream>
#include<string>
#include<stdio.h>
#include<vector>
#include "/usr/local/include/igraph/igraph.h"
#include <map>

using namespace std;


struct graph{
    int id;
    igraph_t g;
    igraph_vector_int_t lables_vertices;
    igraph_vector_int_t lables_arestas;
    igraph_vector_t arestas;
    int num_de_padroes;
    vector <int> lista_de_padroes; // pode ser uma string
    int num_vertices;
    int num_arestas;
    vector < vector <int> > padrao_v;
    vector < vector <int> > padrao_e;
};

typedef struct graph Grafo;
Grafo *getDataset(string, bool);
int getDatasetSize(string nome_arquivo);
vector <int> intersecao(vector <int> v1, vector <int> v2);
bool isIn(vector<int> v1, int elem);
int getNumberJason(string fileJason);
map <int, string> getFilesJson(string files);
map <int, string> getMaximalFiles(string files);
map <int, string> getGroupFiles(string files);
pair<int, int> spliString(string line, char flag);
vector < map <int, int> > getMapDosGrupos(string file);


int main(int argc, char* argv[]) {
    if(argc == 1){
        cout<<"Entre com o nome do arquivo como parâmetro!"<<endl;
        return 0;
    }

    string nome_arquivo_dataset = argv[1]; //Aruivo .gsp
    string nome_arquivo_padores = argv[2]; //Arquivos .fp
    string jasonFilesList = argv[3]; // Arquivos .jason
    string mapGroup = argv[4]; // Arquivo .map

    map <int, string> Grupos = getGroupFiles(nome_arquivo_dataset); // Numero_do_grupo / nome_Do_Arquivo
    map <int, string> Maximais = getMaximalFiles(nome_arquivo_padores);
    map <int, string> arquivosJson = getFilesJson(jasonFilesList);
    vector < map <int, int> > mapeamentoDosGrupos = getMapDosGrupos(mapGroup);

    //Para cada grupo
    for(int z = 1; z <= Grupos.size(); z++){
        //cout << "Grupo " << z << endl;
        Grafo *dataSet= getDataset("grupos/" + Grupos[z], true);
        Grafo *padroesMaximais = getDataset("padroesMaximais/" + Maximais[z], false);
        int sizeDataset = getDatasetSize("grupos/" + Grupos[z]);
        int numero_de_padroes = getDatasetSize("padroesMaximais/" + Maximais[z]);

        igraph_bool_t is_isomorfo = false;
        for(int i =0; i<sizeDataset; i++){
            //cout << i << " ";
            dataSet[i].padrao_v.resize(dataSet[i].num_vertices);
            //dataSet[i].padrao_e.resize(dataSet[i].num_arestas);
            //Verifica se existe isomorfismo entre o padrao e o grafo
            for(int j=0; j<numero_de_padroes; j++){
                igraph_subisomorphic_vf2(&dataSet[i].g,
                        &padroesMaximais[j].g,
                        &dataSet[i].lables_vertices,
                        &padroesMaximais[j].lables_vertices,
                        &dataSet[i].lables_arestas,
                        &padroesMaximais[j].lables_arestas,
                        &is_isomorfo, NULL, NULL, NULL, NULL,NULL);
                //Se tiver isomorfismo, pegua os mapeamentos
                if(is_isomorfo == true){
                    igraph_vector_ptr_t mapeamento;
                    igraph_vector_ptr_init (&mapeamento,0);
                    igraph_get_subisomorphisms_vf2(&dataSet[i].g,
                                    &padroesMaximais[j].g,
                                    &dataSet[i].lables_vertices,
                                    &padroesMaximais[j].lables_vertices,
                                    &dataSet[i].lables_arestas,
                                    &padroesMaximais[j].lables_arestas,
                                    &mapeamento,0,0,0);

                    long int tamanho = igraph_vector_ptr_size(&mapeamento);

                    //Coloca mapeamento em cada vertice de cada grafo;
                    igraph_vector_t * vt;
                    for(int k =0; k<tamanho; k++){
                        vt=(igraph_vector_t*)igraph_vector_ptr_e(&mapeamento,k);
                        for(int l=0; l<igraph_vector_size(vt); l++){
                            //cout<<(int)VECTOR(*vt)[l]<<"  ";
                            int num = (int)VECTOR(*vt)[l];
                            //cout<<num<<" ";
                            if(!isIn(dataSet[i].padrao_v[num], padroesMaximais[j].id )){
                                dataSet[i].padrao_v[num].push_back(padroesMaximais[j].id);
                            }
                        }
                        //cout<<endl;
                    }
                    is_isomorfo = false;
                }
            }
        }
        //Colocas os mapeamentos em cada aresta de cada grafo
        for(int i=0; i<sizeDataset; i++){
            for(int k=0; k<dataSet[i].num_arestas; k++){
                int target = (int) VECTOR(dataSet[i].arestas)[k*2];
                int source = (int) VECTOR(dataSet[i].arestas)[k*2+1];
                dataSet[i].padrao_e.push_back(intersecao(dataSet[i].padrao_v[target], dataSet[i].padrao_v[source]));
            }
        }

    //cout<<endl;
    ifstream jasonFileIn;
    ofstream jasonFileOut;
    char c;
    string fileName;
    for(int i =0; i<sizeDataset; i++){
        fileName = arquivosJson[mapeamentoDosGrupos[z-1][i]];
        //cout << fileName <<endl;
        jasonFileIn.open(fileName.c_str());
        //fileName = "outDir/" + fileName.substr(0,10) + "g" + to_string(z) + "." + fileName.substr(10,(fileName.size()-10));//Para Ricina
        fileName = "outDir/" + fileName.substr(0,10) + "g" + to_string(z) + "." + fileName.substr(10,(fileName.size()-10));//Para cdk
        jasonFileOut.open(fileName.c_str());

        int contador_colchete = 0;
        int contador_chave = -1;
        while (jasonFileIn.get(c)){
            if(c == '[') contador_colchete ++;
            if(c == '{') contador_chave++;

            if((c == '{') && (contador_chave > 0)){
                if(contador_colchete == 1){
                    jasonFileOut << c;
                    jasonFileOut << "\n";
                    jasonFileOut << "\t\t\t\t\"patterns\": [";
                    for(int j =0; j < dataSet[i].padrao_v[contador_chave-1].size(); j++){
                        if(j > 0) jasonFileOut << ",";
                        jasonFileOut << dataSet[i].padrao_v[contador_chave-1][j];
                    }
                    jasonFileOut <<"],";
                    if(contador_chave == dataSet[i].num_vertices) contador_chave = 0;
                } else{
                    jasonFileOut << c;
                    jasonFileOut << "\n";
                    jasonFileOut << "\t\t\t\t\"patterns\": [";
                    for(int j =0; j < dataSet[i].padrao_e[contador_chave-1].size(); j++){
                        if(j > 0) jasonFileOut << ",";
                        jasonFileOut << dataSet[i].padrao_e[contador_chave-1][j];
                    }
                    jasonFileOut <<"],";
                }

            } else{
                jasonFileOut << c;
            }
        }
        jasonFileIn.close();
        jasonFileOut.close();
    }


    }//Fim do for z
}//Fim do main

Grafo *getDataset(string nome_arquivo, bool dataset){
    fstream arquivo;
    char tipo;
    int numero_de_grafos = getDatasetSize(nome_arquivo);
    Grafo *lista_de_grafos = new Grafo[numero_de_grafos];

    /*------------------------------------------------------------
     Percorre o arquivo e obtem o numero de vertices e
     arestas dos grafos
    --------------------------------------------------------------*/
    arquivo.open(nome_arquivo.c_str()); //Abre arquivo
    int iterador = -1; //Iterador que identifica o ID de cada grafo
    arquivo >> tipo; // Faz a leitura do primeiro caractere
    //Ler cada caractere do arquivo ate que o mesmo termine
    while(!arquivo.eof()){
        switch (tipo){
            //identificacao do grafo. Significa que eh um novo grafo
            case 't':
                iterador++;//Atualiza o iterador
                // Inicializa os valaores de vertices e arestas
                lista_de_grafos[iterador].num_vertices = 0;
                lista_de_grafos[iterador].num_arestas = 0;
                break;

            case 'v': //Conta um vertice para o grafo
                lista_de_grafos[iterador].num_vertices++;
                break;

            case 'e': //Conta uma aresta para o grafo
                lista_de_grafos[iterador].num_arestas++;
                break;
        }
        arquivo >> tipo;//Ler proximo caractere
    }
    arquivo.close(); //Fecha arquivo
    /*------------------------------------------------------------
     Percorre o arquivo e inicializa todos os grafos
    --------------------------------------------------------------*/
    arquivo.open(nome_arquivo.c_str());
    for(int i = 0; i < numero_de_grafos; i++){
        int id, id2, label, iterador = 0;
        char caractere, *str;
        igraph_vector_t arestas;//Lista de arestas
        //Verifica o tipo de item a ser lido:
        /* -----------------------------------------
                    Inicializando o grafo
         ------------------------------------------*/
        arquivo >> caractere; // caractere t
        arquivo >> caractere; // caractere #
        arquivo >> id; // ID do grafo
        //seta o ID do grafo
        lista_de_grafos[i].id = id;
        if(dataset == false){
            arquivo >> caractere; //caractere *
            arquivo >> id; //numero de padroes do grafo
            //Seta o numero de padroes do grafo
            lista_de_grafos[i].num_de_padroes = id;
        }

        //Cria lista de rotulos dos vertices
        igraph_vector_int_init(&lista_de_grafos[i].lables_vertices, lista_de_grafos[i].num_vertices);
        //Cria lista de rotulos das arestas
        igraph_vector_int_init(&lista_de_grafos[i].lables_arestas, lista_de_grafos[i].num_arestas);
        //Inicializa vetor com arestas
        igraph_vector_init(&lista_de_grafos[i].arestas,lista_de_grafos[i].num_arestas * 2);
        /* ----------------------------------------------
                Inicializando vertices do grafo
         ----------------------------------------------*/
        for(int j = 0; j < lista_de_grafos[i].num_vertices;j++){
            arquivo >> caractere; //caractere v
            arquivo >> id; // ID do vertice
            arquivo >> label; // Rotulo do vertice
            //Insere rotulo na lista de rotulos do grafo i no vertice ID.
            VECTOR(lista_de_grafos[i].lables_vertices)[id] = label;
        }//Fim do for (j)
         /* ----------------------------------------------
                Inicializando arestas do grafo
         ----------------------------------------------*/
        for(int j = 0; j < lista_de_grafos[i].num_arestas;j++){
            arquivo >> caractere; //caractere e
            arquivo >> id; //vertice 1
            arquivo >> id2; // vertice 2
            arquivo >> label; // rotulo da aresta
            //Adiciona aresta na lista de arestas
            VECTOR(lista_de_grafos[i].arestas)[j*2]=id; VECTOR(lista_de_grafos[i].arestas)[j*2+1]=id2;
            //Insere rotulo na lista de rotulos do grafo i no aresta j.
            VECTOR(lista_de_grafos[i].lables_arestas)[j] = label;
        }//Fim do for (j)
         /* ----------------------------------------------
                Inicializando lista de padroes
         ----------------------------------------------*/
        if(dataset == false){
			arquivo >> caractere; //caractere x
            for(int j = 0; j < lista_de_grafos[i].num_de_padroes; j++){
                arquivo >> id; //Numero do grafo onde se encontra o padrao
                //Insere rotulo na lista de grafos em que o grafo i eh padrao.
                lista_de_grafos[i].lista_de_padroes.push_back(id);
            }//Fim do for (j)
        }

        //Cria o grafo (Grafo, Lista_com_arestas, Numero_de_vertices, Tipo)
        igraph_create(&lista_de_grafos[i].g, &lista_de_grafos[i].arestas,
            lista_de_grafos[i].num_vertices, IGRAPH_UNDIRECTED);
        //Desaloca vetor de arestas
        //igraph_vector_destroy(&arestas);
    }//Fim do for(i)
    arquivo.close();//Fecha arquivo
    return lista_de_grafos;
}

int getDatasetSize(string nome_arquivo){
    int numero_de_grafos = 0;
    char tipo;
    fstream arquivo;
    /*------------------------------------------------------------
     Percorre o arquivo e obtem o numero de grafos
    --------------------------------------------------------------*/
    arquivo.open(nome_arquivo.c_str());//Abre arquivo
    arquivo >> tipo;// Faz a leitura do primeiro caractere
    //Ler cada caractere do arquivo ate que o mesmo termine
    while(!arquivo.eof()){
        //Incrementa a quantidade de grafos qundo encontra um 't'
        if(tipo == 't')
            numero_de_grafos++;
        arquivo >> tipo;//Ler proximo caractere
    }
    arquivo.close();
    //cout << numero_de_grafos <<endl;
    return numero_de_grafos;
}

//Retorna a interseção entre dois vectors
vector <int> intersecao(vector <int> v1, vector <int> v2){
    vector <int> saida;
    for(int i =0; i<v1.size(); i++){
        if(isIn(v2, v1[i])) saida.push_back(v1[i]);
    }
    return saida;
}

//Verifica se um elemento estar no vector
bool isIn(vector<int> v1, int elem){
    for(int i=0; i<v1.size(); i++){
        if(v1[i] == elem) return true;
    }
    return false;
}

//Retorna o numero correspondente ao nome do arquivo .jason
int getNumberJason(string fileJason){
    string number;
    for(int i =0; i<(fileJason.size()-11); i++){
        number += fileJason[i];
        if(fileJason[i] == '.') number = "";
    }
    return atoi(number.c_str());
}

//Retorna mapeamento entre os arquivos .jason e o numero do grafo a que pertence.
map <int, string> getFilesJson(string files){
    map <int, string> arquivosJson;
    ifstream in(files.c_str());
    string line;

    in >> line;
    while(!in.eof()){
        arquivosJson.insert(pair <int, string> (getNumberJason(line), line));
        in >>line;
    }
    in.close();
    return arquivosJson;
}

map <int, string> getGroupFiles(string files){
    map <int, string> arquivosGroup;
    ifstream in(files.c_str());
    string line;

    in >> line;
    while(!in.eof()){
        string number = line.substr(1, (line.size()-4));
        arquivosGroup.insert(pair <int, string> (atoi(number.c_str()), line));
        in >>line;
    }
    in.close();
    return arquivosGroup;
}

map <int, string> getMaximalFiles(string files){
    map <int, string> arquivosMax;
    ifstream in(files.c_str());
    string line;

    in >> line;
    while(!in.eof()){
        string number = line.substr(1, (line.size()-19));
        arquivosMax.insert(pair <int, string> (atoi(number.c_str()), line));
        in >>line;
    }
    in.close();
    return arquivosMax;
}

pair<int, int> spliString(string line, char flag){
	pair <int, int> p;
	string graph1 = "", group1 = "";
	int graph2, group2, positionDelimiter = 0;

	for(int i = 0; i < line.size(); i++){
		if(line[i] == flag) break;
		graph1 += line[i];
		positionDelimiter ++;
	}
	for(int i = (positionDelimiter+1); i < line.size(); i++){
        if(line[i] == flag) break;
		group1 += line[i];
	}

	graph2 = atoi(graph1.c_str());
    group2 = atoi(group1.c_str());
	p = make_pair(graph2, group2);
	return p;

}

vector < map <int, int> > getMapDosGrupos(string file){
    vector < map <int, int> > mape;
    ifstream in(file.c_str());
    string line;
    int contador = 0;
    in >> line;
    while(!in.eof()){
        if(line[0] == '#'){
            contador++;
            map <int, int> m;
            mape.push_back(m);
            in >> line;
        }
        pair <int, int> p = spliString(line, ',');
        //cout << p.first << " "<< p.second <<endl;
        mape[contador-1].insert(p);
        in >> line;
    }
    return mape;
}


