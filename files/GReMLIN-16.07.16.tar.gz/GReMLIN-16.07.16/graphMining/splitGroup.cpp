/*----------------------------------------
* Depertamento de Informática - UFV
* Charles Abreu Santana - Mat: 87858
* Ultima modificação: 07/06/2016
*-----------------------------------------*/
/*.
* Entrada: Um arquivo gsp e  um mapeamento grafo ->  grupo
* Retorana varios arquivos gsp. Um para cada grupo
*/

#include<iostream>
#include<fstream>
#include<stdio.h>
#include<string>
#include <map>
#include <utility>
#include <stdlib.h>
#include<vector>
#include <fstream>
#include <string>
//#include<sstream>
using namespace std;

typedef string Grafo; // O grafo eh representado por uma string

int getNumGroups(map <int, int> mapeamento);
vector <Grafo> getDataset(string str);
map <int, int> getMapeamento(string str);
pair<int, int> spliString(string line, char flag);
void imprimeMap(map <int, int> mapeamento);
void imprimeDataset(vector <Grafo> v);
int getNumber(Grafo g);
void imprimeGrupos(vector <vector <Grafo> > v);
string getGraphNoNumber(Grafo g);

int main(int argc, char* argv[]){

    if(argc == 1){
        cout<<"Entre com o nome do arquivo como parâmetro!"<<endl;
        return 0;
    }
    string dataset = argv[1]; //dataset com os grafos (arquivo .gsp)
    string arquivoMape = argv[2]; //arquivo com o mapeamento dos grupos
	//int numGroups = atoi(argv[3]);
    
    map <int, int> mapeamento = getMapeamento(arquivoMape);	
	vector <Grafo> graphDataset = getDataset(dataset); 
	int numGroups = getNumGroups(mapeamento);
	vector <vector <Grafo> > grupos;
	
	for(int i=0; i<=numGroups; i++){
		vector <Grafo> g;
		grupos.push_back(g);
	}
	
	for(int i =0; i< graphDataset.size(); i++){
		int numeroDoGrafo = getNumber(graphDataset[i]);
		int numeroDoGrupo = mapeamento[numeroDoGrafo];
		grupos[numeroDoGrupo].push_back(graphDataset[i]);
	}
	
	imprimeGrupos(grupos);
	//cout << getNumber(graphDataset[0]) << getNumber(graphDataset[133]);
    //Grafo grupos[numGroups];
	//imprimeDataset(graphDataset);
	//imprimeMap(mapeamento);
	
    
}

int getNumGroups(map <int, int> mapeamento){
	int maior = 0;
	int aux;
	map <int, int>::iterator it;
	for( it = mapeamento.begin(); it != mapeamento.end(); it++){
        aux = it->second;
        if (aux > maior) maior = aux;
	}
	return maior;
}

void imprimeGrupos(vector <vector <Grafo> > v){
	ofstream outgrupo, outmapeamento;
	outmapeamento.open("grupo.map");
	
	for(int i = 1; i < v.size(); i++){
		int contador = 0;
		string nomeDoGrupo = "g" + to_string(i)+".gsp";
		outgrupo.open(nomeDoGrupo.c_str());
		outmapeamento <<"#"<<i<<"\n";
		for(int j=0; j< v[i].size(); j++){
			outmapeamento << contador<<","<< getNumber(v[i][j])<<"\n";
			outgrupo <<"t # "<< contador<< getGraphNoNumber(v[i][j]);
			contador++;
		}
		outgrupo.close();
		contador=0;
	}	
	outmapeamento.close();
}

string getGraphNoNumber(Grafo g){
	int contador = 0;
	for(int i=0; i < g.size(); i++){
		if(g[i] == '\n') break;
		contador++;
	}
	return g.substr(contador, (g.size()-1));
}

vector <Grafo> getDataset(string str){
	ifstream in(str.c_str());
	char caractere;
	vector <Grafo> dataset;
	Grafo g = "";
	
	while(in.get(caractere)){
		//cout<<caractere;
		if((caractere == 't') && (g.compare("") != 0)){
			dataset.push_back(g);
			g = "";
		}
		g += caractere;
	}	
	in.close();
	dataset.push_back(g);
	return dataset;
}

map <int, int> getMapeamento(string str){
	ifstream in(str.c_str());
	string linha;
	map <int, int> m;
	in >> linha;
	
	while(!in.eof()){
		//cout<<linha<<endl;
		pair <int, int> p = spliString(linha,',');
		m.insert(p);
		in >> linha;
	}
	return m;
}

pair<int, int> spliString(string line, char flag){
	pair <int, int> p;
	string graph1 = "", group1 = "";
	int graph2, group2, positionDelimiter = 0;

	for(int i = 0; i < line.size(); i++){
		if(line[i] == flag) break;
		graph1 += line[i];
		positionDelimiter ++;
	}
	for(int i = (positionDelimiter+1); i < line.size(); i++){
		group1 += line[i];
	}
	
	graph2 = atoi(graph1.c_str());
    group2 = atoi(group1.c_str());
	p = make_pair(graph2, group2);
	return p;

}

void imprimeMap(map <int, int> mapeamento){
    map <int, int>::iterator it;
	for( it = mapeamento.begin(); it != mapeamento.end(); it++){
        cout<< it->first <<" - "<< it->second <<endl;
	}
 }
 
 void imprimeDataset(vector <Grafo> v){
	 for(int i =0; i< v.size(); i++){
		 cout<<v[i];
	 }
 }
 
 int getNumber(Grafo g){
	 string num;
	 for(int i =4; ;i++){
		 if(g[i] == '\n') break;
		 num += g[i];
	 }
	 return atoi(num.c_str());
 }
