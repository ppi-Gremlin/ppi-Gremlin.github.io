#-----------------------------------------------------------------------
# Structural Bioinformatics Group DPI-Universidade Federal de Vicosa
# Developed by Sabrina Azevedo
# 24/06/2016
#-----------------------------------------------------------------------

import os.path
import getopt
import constants
import re
import sys

def parseListOfGspan(listOfGspanFiles, mapGraphIndex, atomTypeMapping, edgeTypeMapping):
    with open(listOfGspanFiles) as fp:
        for line in fp:
            line = line.strip('\n')
            if os.path.isfile(line):
                castGraphmlToJson(line, mapGraphIndex, atomTypeMapping, edgeTypeMapping)
            else:
                print("The file does not exist: ", line);
    fp.close()

def createGspanGroupToGeneralGraphIndexMap(mapGraphIndexFromGspanToGeneral):
    mapGraphIndex = {}
    groupIndex = ""
    groupIndex = ""
    generalIndex = ""
    with open(mapGraphIndexFromGspanToGeneral) as fp:
        for line in fp:
            line = line.strip('\n').lower()
            searchObjGroup = re.search(r'#(\d+).*$', line)
            if searchObjGroup:
                groupIndex = searchObjGroup.group(1)
            searchObjGraphIndexMap = re.search(r'(\d+),(\d+).*$', line)
            if searchObjGraphIndexMap:
                graphIndexInGroup = searchObjGraphIndexMap.group(1)
                graphIndexGeneral = searchObjGraphIndexMap.group(2)
                key = groupIndex + "_" + graphIndexInGroup
                if key not in mapGraphIndex:
                    mapGraphIndex[key] = graphIndexGeneral
    fp.close()

    return mapGraphIndex

def castGraphmlToJson(gspanFile, mapGraphIndex, atomTypeMapping, edgeTypeMapping):
    searchObjFpGspan = re.search(r'g(\d+)\.gsp_(.+)\.maximal\.fp$', gspanFile)
    contEdge = 0
    if searchObjFpGspan:
        groupIndex = searchObjFpGspan.group(1)
        listGraphml = [] # this variable contains the graph in string format. We used a list because string is imutable
        listGraphml.append("{")
        listGraphml.append("\n   \"nodes\" : [")

        with open(gspanFile) as fp:
            for line in fp:
                line = line.strip('\n')
                # t # 4 * 10
                searchObjGraph = re.search(r't\s+#\s+(\d+)\s+\*\s+(\d+)$', line)
                if searchObjGraph:
                    patternIndex = searchObjGraph.group(1)
                    outfile = gspanFile + ".patternIndex" + patternIndex + ".json"
                    fout = open(outfile, 'w')

                # v 0 7
                searchObjNode = re.search(r'v\s+(\d+)\s+(\d+)$', line)
                if searchObjNode:
                    listGraphml.append("\n      {")
                    nodeIndex = searchObjNode.group(1)
                    atomType = searchObjNode.group(2)
                    atomTypeStr = castIntToStrAtomType(atomType, atomTypeMapping)
                    listGraphml.append("\n         \"index\": " + nodeIndex + constants.sepVirg)
                    listGraphml.append("\n         \"atomType\" : \"" + atomTypeStr + "\"" + constants.sepVirg)
                    #listGraphml.append("\n         \"atomTypeInt\" : \"" + atomType + "\"" + constants.sepVirg)
                    listGraphml.append("\n         \"atomTypeInt\" : \"" + atomType + "\"")
                    listGraphml.append("\n      }")
                    listGraphml.append(",")

                #e 0 1 23
                searchObjEdge = re.search(r'e\s+(\d+)\s+(\d+)\s+(\d+)$', line)
                if searchObjEdge:
                    contEdge = contEdge + 1
                    if contEdge == 1: ## contEdge ==1 quando acha primeira aresta fecha a secao de nos e abre a de links no json
                        del listGraphml[-1] # remove the coma from last node },
                        listGraphml.append("\n   ],")
                        listGraphml.append("\n   \"links\" : [")
                    listGraphml.append("\n      {")
                    source = searchObjEdge.group(1)
                    target = searchObjEdge.group(2)
                    edgeType = searchObjEdge.group(3)
                    edgeTypeStr = castIntToStrEdgeType(edgeType, edgeTypeMapping)
                    listGraphml.append("\n         \"source\" : " + source + constants.sepVirg)
                    listGraphml.append("\n         \"target\" : " + target + constants.sepVirg)
                    listGraphml.append("\n         \"interactionType\" : \"" + edgeTypeStr + "\"" + constants.sepVirg)
                    listGraphml.append("\n         \"interactionTypeInt\" : \"" + edgeType + "\"")
                    listGraphml.append("\n      }")
                    listGraphml.append(",")

                searchObjCloseGraph = re.search(r'x\s+(.+)$', line)
                if searchObjCloseGraph:
                    del listGraphml[-1]  # remove the coma from last edge
                    listGraphml.append("\n   ],")
                    #"graphproperties": {
                    #    "inputgraphs": [1, 2, 3]
                    #}
                    #"inputgraphs": [1, 2, 3]
                    listGraphml.append("\n   \"graphproperties\" : {")
                    listGraphml.append("\n         \"inputgraphs\" : [")
                    originalInputGraph = searchObjCloseGraph.group(1).replace(" ", ",")
                    originalInputGraph = originalInputGraph[:-1]
                    #
                    temp = originalInputGraph.split(",")
                    for x in temp:
                        graphIndexInGroup = x
                        key = groupIndex + "_" + graphIndexInGroup
                        graphIndexGeneral = mapGraphIndex[key]
                        listGraphml.append(graphIndexGeneral)
                        listGraphml.append(",")
                    #
                    del listGraphml[-1] # remove the coma
                    #listGraphml.append(originalInputGraph)
                    listGraphml.append("]")



                    listGraphml.append("\n   }")
                    listGraphml.append("\n}")
                    strJsonGraph = "".join(listGraphml)
                    fout.write(strJsonGraph)
                    fout.close()
                    listGraphml = []
                    listGraphml.append("{")
                    listGraphml.append("\n   \"nodes\" : [")
                    contEdge = 0
    else:
        print("The file is not a gspanFile: ", gspanFile);

def createAminoAcidsMap(listOfAminoAcids):
    mapAminoAcids = {}
    with open(listOfAminoAcids) as fp:
        for line in fp:
            aminoAcid = line.strip('\n').upper()
            if aminoAcid not in mapAminoAcids:
                mapAminoAcids[aminoAcid] = 0
    fp.close()
    return mapAminoAcids

def createAtomOrInteractionIntToStrTypeMap(atomOrInteractionTypeFile):
    atomOrInteractionTypeMapping = {}
    with open(atomOrInteractionTypeFile) as fp:
        for line in fp:
            line = line.strip('\n')
            vectorTemp = line.split(constants.sepPv)
            type = vectorTemp[0] # string atom or interaction type
            value = vectorTemp[1] # prime number representing atom or interaction type
            atomOrInteractionTypeMapping[value] = type
    fp.close()
    return atomOrInteractionTypeMapping

def prime_factors(n):
    i = 2
    factors = []
    while i * i <= n:
        if n % i:
            i += 1
        else:
            n //= i
            factors.append(i)
    if n > 1:
        factors.append(n)
    return factors

def castIntToStrAtomType(atomType, atomTypeMapping):
    listOfIntAtomTypes = prime_factors(int(atomType))
    stringAtomType = ""
    for intType in listOfIntAtomTypes:
        stringAtomType = stringAtomType + atomTypeMapping[str(intType)] + "/"
    stringAtomType = stringAtomType[:-1]
    return stringAtomType

def castIntToStrEdgeType(edgeType, edgeTypeMapping):
    listOfIntEdgeTypes = prime_factors(int(edgeType))
    stringEdgeType = ""
    for intType in listOfIntEdgeTypes:
        stringEdgeType =  stringEdgeType + edgeTypeMapping[str(intType)] + "/"
    stringEdgeType = stringEdgeType[:-1]
    return stringEdgeType

#-----------------------------------------------------------------------------------------------------------------------
def main(argv):
    atomType = ''
    interactionType = ''
    listOfAminoAcids = ''
    listOfGspanFiles = ''
    try:
        opts, args = getopt.getopt(argv,"ha:i:g:m:",["afile=","ifile=","gfile=", "mfile="])
    except getopt.GetoptError:
        print ('castGraphmlToJson.py -a <atomTypeFile> -i <interactionTypeFile> -g <graphfilelist> -m <mapGraphIndexFromGspanToGeneral>')
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print ('castGraphmlToJson.py -a <atomTypeFile> -i <interactionTypeFile> -g <graphfilelist> -m <mapGraphIndexFromGspanToGeneral>')
            sys.exit()
        elif opt in ("-a", "--afile"):
            atomType = arg
        elif opt in ("-i", "--ifile"):
            interactionType = arg
        elif opt in ("-g", "--gfile"):
            listOfGspanFiles = arg
        elif opt in ("-m", "--mfile"):
            mapGraphIndexFromGspanToGeneral = arg

    #mapAminoAcids = createAminoAcidsMap(listOfAminoAcids)
    atomTypeMapping = createAtomOrInteractionIntToStrTypeMap(atomType)
    edgeTypeMapping = createAtomOrInteractionIntToStrTypeMap(interactionType)
    mapGraphIndex = createGspanGroupToGeneralGraphIndexMap(mapGraphIndexFromGspanToGeneral)
    parseListOfGspan(listOfGspanFiles, mapGraphIndex, atomTypeMapping, edgeTypeMapping)


if __name__ == "__main__":
    main(sys.argv[1:])
