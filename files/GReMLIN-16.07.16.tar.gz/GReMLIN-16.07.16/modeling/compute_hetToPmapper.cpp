/*----------------------------------------
* Depertamento de Informática - UFV
* Charles Abreu Santana - Mat: 87858
* Ultima modificação: 17/05/2016
*-----------------------------------------*/
/* Este programa extrai ligantes de um arquivo PDB. */
#include<iostream>
#include<fstream>
#include<stdio.h>
#include<string>
#include<vector>
#include<sstream>
using namespace std;
//Set eh um vector de string
typedef vector <string> Set;
typedef vector < pair< string, Set> > Map;

Set insereElemento(Set s, string str);
bool isIn(Set s, string str);
Set readArtifactList(char *fileName);
Set readNonArtifactList(string fileName);
void imprimeSet(Set s);
string getTag(string str);
string eliminaEspaco(string str);
bool isVoid(string str);
bool isIntersection(Set s1, Set s2);
Set uniao(Set s1, Set s2);
void toSet(Set s1);
bool conjuntoDisjunto(Set s1, Set s2);
string concatenaStrings(Set s);

int main(int argc, char* argv[]){

    if(argc == 1){
        cout<<"Entre com o nome do arquivo como parâmetro!"<<endl;
        return 0;
    }
    string infilePdbChainList = argv[1]; //Lista de arquivos pdb
    string nonArtifactLigands = argv[2]; //

    string nome_do_arquivo;
    ifstream in;

    in.open(infilePdbChainList.c_str());

    ofstream arquivo_de_saida;
    arquivo_de_saida.open("outDir/ComputeTrueHetatmToPmapper/pdb_lig/lista_arquivos_ligands.txt");



    Set listOfNonArtifactLigands = readNonArtifactList(nonArtifactLigands);

    char linha_PDB_chain [512];
    in.getline(linha_PDB_chain, 512);

    while(!in.eof()){
        cout<<linha_PDB_chain<<endl;
        ifstream arquivo_PDB (linha_PDB_chain);
        char linha_char[512];
        string linha_string, tag;
        ofstream saida; //fluxo dos arquivos de saida
        vector <string> listaDeLigantes; //ligantes encontrados ate o momento
        string oldLigand = " "; // ligante da execucao anterior
        vector <pair<string, string> > mapeamento; //mapeamento atomo -> ligante
        vector <Set> setFiles;
        Set ligandList; //Lista com todos os ligantes validos do arquivo corrente

        arquivo_PDB.getline(linha_char, 512);
        bool possui_ligante_valido = false;

        while(!arquivo_PDB.eof()){

            linha_string = linha_char;
            tag = getTag(linha_string);

            if(tag.compare("HETATM") == 0){
                string elementSymbol = eliminaEspaco(linha_string.substr(76,2));
                string ligandName = eliminaEspaco(linha_string.substr(17,3)); // Nome do ligante
                string ligandSequence = eliminaEspaco(linha_string.substr(22,4));
                string atomSerial = eliminaEspaco(linha_string.substr(6,5));
                string ligandId = ligandName + "_" + ligandSequence; //Nome do ligante + Numero de sequencia
                if(isIn(listOfNonArtifactLigands,ligandName)){
                    possui_ligante_valido = true;
                    ligandList.push_back(ligandId);
                    mapeamento.push_back(make_pair(atomSerial, ligandId));
                    if(ligandId.compare(oldLigand) != 0){
                        listaDeLigantes.push_back(ligandId);
                        if(listaDeLigantes.size() > 0) saida.close();
                        string fileName = linha_PDB_chain;
                        fileName = "outDir/ComputeTrueHetatmToPmapper/pdb_lig/" + fileName.substr(fileName.size()-10, 6) + "." + ligandId +".lig";
                        saida.open(fileName.c_str());
                        oldLigand = ligandId;
                        //cout<<fileName<<endl;
//                        //saida << linha_string <<"\n";
                    }
                    saida << linha_string <<"\n";
                }
                //cout << elementSymbol << "  -  "<<ligandName<<"\n";
            } else if (tag.compare("CONECT") == 0){
                if(possui_ligante_valido){
                    Set set_ligantes;
                    for(int i=6; i<linha_string.size(); i+=5){
                        string lig = eliminaEspaco(linha_string.substr(i,5));
                        if(isVoid(lig)) break; // Quando encontra lig vazio termina a iteracao
                        set_ligantes.push_back(lig);
                    }
                    //cout<<linha_string;
                    setFiles.push_back(set_ligantes);
                    //imprimeSet(set_ligantes);
                    //cout<<endl;
                }
            }
            arquivo_PDB.getline(linha_char, 512);
        }
        saida.close();
        if(possui_ligante_valido){
            for(int k = 0; k < setFiles.size(); k++){
                for(int i =0; i< setFiles[k].size(); i++){
                    bool mapeou = false;
                    for(int j=0; j< mapeamento.size(); j++){
                        if(setFiles[k][i].compare(mapeamento[j].first) == 0){
                            setFiles[k][i] = mapeamento[j].second;
                            mapeou = true;
                            break;
                        }
                    }
                    if(!mapeou) setFiles[k][i] = "NULL";
                }
            }

            vector <Set> setFile_auxiliar;

            //Tranformar em conjunto
            for(int i = 0; i<setFiles.size(); i++){
                Set aux;
                for(int j = 0; j < setFiles[i].size(); j++){
                    if(setFiles[i][j].compare("NULL") == 0){
                        continue;
                    } else{
                        aux = insereElemento(aux, setFiles[i][j]);
                    }
                }
                if(aux.size() > 0){
                    setFile_auxiliar.push_back(aux);
                }
            }

            setFiles = setFile_auxiliar;
            setFile_auxiliar.clear();


            vector <Set> arquivos_ligands;
            arquivos_ligands.push_back(setFiles[0]);

            for(int i = 1; i < setFiles.size(); i++){
                for(int j = 0; j< arquivos_ligands.size(); j++){
                    if(!conjuntoDisjunto(setFiles[i], arquivos_ligands[j])){
                        arquivos_ligands[j] = uniao(setFiles[i],arquivos_ligands[j]);
                        break;
                    } else if(j == (arquivos_ligands.size() - 1))
                        arquivos_ligands.push_back(setFiles[i]);
                }

            }

            for(int i =0; i < ligandList.size(); i++){
                for(int j = 0; j< arquivos_ligands.size(); j++){
                    if(isIn(arquivos_ligands[j], ligandList[i])) break;
                    else if(j == (arquivos_ligands.size() - 1)){
                        Set s;
                        s.push_back(ligandList[i]);
                        arquivos_ligands.push_back(s);
                    }

                }

            }

            for(int i =0; i < arquivos_ligands.size(); i++){
                string fileName = linha_PDB_chain;
                string nome_do_ligand = concatenaStrings(arquivos_ligands[i]);
                nome_do_ligand = "outDir/ComputeTrueHetatmToPmapper/pdb_ligands/"+ fileName.substr(fileName.size()-10, 6) + "." + nome_do_ligand + ".ligand";
                arquivo_de_saida << nome_do_ligand << "\n" << arquivos_ligands[i].size() << "\n";


                for(int j = 0; j < arquivos_ligands[i].size(); j++){
                    string nome_lig; // Nome do arquivo .lig
                    nome_lig = "outDir/ComputeTrueHetatmToPmapper/pdb_lig/" + fileName.substr(fileName.size()-10, 6) + "." + arquivos_ligands[i][j] + ".lig";
                    cout << arquivos_ligands[i][j]<<endl;
                    arquivo_de_saida << nome_lig <<"\n";
                }
                arquivo_de_saida <<"\n\n";
            }
        }
        mapeamento.clear();
        in.getline(linha_PDB_chain, 512);
    }
    in.close();
    arquivo_de_saida.close();
    cout << "Done!\n";
}//Fim do main

//Insere uma string em uma vector de string
Set insereElemento(Set s, string str){
    if(s.empty()){
        s.push_back(str);
    } else{
        for(int i=0; i < s.size(); i++){
            if(s[i].compare(str) == 0) return s;
        }
        s.push_back(str);
    }
    return s;
}//Fim insere elemento

//Verifica de elemento esta contido no conjunto
bool isIn(Set s, string str){
    if(s.empty()) return false;
    for(int i=0; i < s.size(); i++){
        if(s[i].compare(str) == 0) return true;
    }
    return false;
}//Fim IsIn

Set readArtifactList(char *fileName){
    fstream entrada(fileName);
    string str;
    Set artefatos;
    entrada >> str;
    while(!entrada.eof()){
        artefatos = insereElemento(artefatos, str);
        entrada >> str;
    }//Fim do while
    return artefatos;
}//Fim de readArtifactList

void imprimeSet(Set s){
    for(int i=0; i<s.size(); i++) cout<<s[i]<<"\t";
}//Fim imprimeSey

//Retorna a tag de uma linha PDB
string getTag(string str){
    string tag = "";
    for(int i=0; i < str.size(); i++){
        if(str[i] == ' '){
            return tag;
        } else{
            tag.push_back(str[i]);
        }
    }
}

Set readNonArtifactList(string fileName){
    fstream entrada(fileName.c_str());
    string str;
    Set artefatos;
    entrada >> str;
    while(!entrada.eof()){
        str = str.substr(0,3);
        artefatos = insereElemento(artefatos, str);
        entrada >> str;
    }//Fim do while
    return artefatos;
}//Fim de readArtifactList

//Elimina espacos vazios  do inicio e fim de uma string
string eliminaEspaco(string str){
    int inicio = 0, fim = str.size();
    for(int i =0; i<str.size(); i++){
        if(str[i] != ' ') {
            inicio = i;
            break;
        }
    }
    for(int j = str.size(); j>=0; j--){
        if(str[j] != ' '){
            fim = j;
            break;
        }
    }
    return str.substr(inicio, fim - inicio);
}

bool isVoid(string str){
    for(int i=0; i< str.size(); i++){
        if(str[i] != ' ') return false;
    }
    return true;
}

bool isIntersection(Set s1, Set s2){
    if(s1.empty() || s2.empty()) return true;
    for(int i =0; i < s1.size(); i++){
        for(int j=0; j < s2.size(); j++){
            if(s1[i].compare(s2[j]) == 0) return true;
        }
    }
    return false;
}

bool conjuntoDisjunto(Set s1, Set s2){
    if(s1.empty() || s2.empty()) return false;
    for(int i =0; i < s1.size(); i++){
        for(int j=0; j < s2.size(); j++){
            if(s1[i].compare(s2[j]) == 0) return false;
        }
    }
    return true;
}

Set uniao(Set s1, Set s2){
    Set s3;
    for(int i=0; i < s1.size(); i++){
        s3 = insereElemento(s3, s1[i]);
    }
    for(int i=0; i<s2.size(); i++){
        s3 = insereElemento(s3, s2[i]);
    }
    return s3;
}

void toSet(Set s1){
    Set aux;
    for (int i=0; i<s1.size(); i++){
        insereElemento(aux,s1[i]);
    }
    s1 = aux;
}

string concatenaStrings(Set s){
    string str;
    for(int i = 0; i< s.size(); i++){
        if(i == 0){
            str = str + s[i];
            continue;
        }
        str = str +"."+ s[i];
    }
    return str;
}
