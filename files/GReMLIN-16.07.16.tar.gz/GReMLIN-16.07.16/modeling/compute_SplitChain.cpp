/*----------------------------------------
* Depertamento de Informática - UFV
* Charles Abreu Santana - Mat: 87858
* Ultima modificação: 29/02/2016
*-----------------------------------------*/
/* Este programa particiona um arquivo PDB em funcao de suas Chains. */
#include<iostream>
#include<fstream>
#include<stdio.h>
#include<string>
#include<vector>
#include<sstream>
using namespace std;

string getTag(string str){
    string tag = "";
    for(int i=0; i < str.size(); i++){
        if(str[i] == ' '){
            return tag;
        } else{
            tag.push_back(str[i]);
        }
    }
}

int main(int argc, char* argv[]){

    if(argc == 1){
        cout<<"Entre com o nome do arquivo como parâmetro!"<<endl;
        return 0;
    }
    cout<<"Iniciando Compute Split Chain ...\n";

    string infilePdbIds = argv[1];
    string outDir = argv[2];
    string dirPdbData = argv[3];

    fstream arquivo_pdbids(infilePdbIds.c_str());
    string nome_do_arquivo;
    string lineInPdb;
    arquivo_pdbids >> lineInPdb;
    cout << "Lendo lista de arquivos ...\n";
    while(!arquivo_pdbids.eof()){ // le lista de pdb ids
        nome_do_arquivo = dirPdbData + "/" + lineInPdb;
        fstream arquivoPdb(nome_do_arquivo.c_str());
        string tag;
        arquivoPdb >> tag;
        string chainSplits;
        while(!arquivoPdb.eof()){ // PErcorre arquivo PDB
            if(tag.compare("COMPND") == 0){
                arquivoPdb >> tag >> tag;
                if(tag.compare("CHAIN:") == 0){
                    char chain = ' ';
                    while(chain != '\n'){
                        arquivoPdb.get(chain);
                        if((chain != ';') && (chain !='\n') && (chain !=' ') && (chain !=',')){
                            chainSplits.push_back(chain);// Tranforma char em string
                        }
                    }
                }
            } else{
                arquivoPdb.ignore(1000, '\n');
            }
            arquivoPdb >> tag;
        }// fim do while: achou o fim de arquivo PB
        //cout<<chainSplits<<endl;
        arquivoPdb.close();

        char linhaPDBC[256];
        string linhaPDBS;
        string ligandChain;
        ofstream arquivoSaida;

        for(int i=0; i < chainSplits.size(); i++){
            nome_do_arquivo = dirPdbData + "/" + lineInPdb;
            arquivoPdb.open(nome_do_arquivo.c_str());
            nome_do_arquivo = outDir + "/" + lineInPdb.substr(0, (lineInPdb.size()-4)) +"."+ chainSplits[i] +".pdb";
            arquivoSaida.open(nome_do_arquivo.c_str());
            arquivoPdb.getline(linhaPDBC, 256);
            while(!arquivoPdb.eof()){ // PErcorre arquivo PDB
                linhaPDBS = linhaPDBC;
                tag = getTag(linhaPDBS); //Identifica a tag da linha do arquivo PDB
                if(tag.compare("ATOM") == 0){//Procura pelo identificador ATOM
                    ligandChain = linhaPDBS.substr(21,1);
                    if(ligandChain[0] == chainSplits[i]) //Verifica se a Chain corresponde ao arquivo corrente
                        arquivoSaida << linhaPDBS <<"\n";
                } else if (tag.compare("HETATM") == 0){ //Procura pelo identificador HETATM
                    ligandChain = linhaPDBS.substr(21,1);
                    if(ligandChain[0] == chainSplits[i])
                        arquivoSaida << linhaPDBS <<"\n";
                } else{
                    arquivoSaida << linhaPDBS <<"\n";
                }
                arquivoPdb.getline(linhaPDBC, 256);
            }// fim do while: achou o fim de arquivo PB
            arquivoPdb.close();
            arquivoSaida.close();
        }//Fim do for
        arquivo_pdbids >> lineInPdb;
    }//Fim do while: achou o fim da lista de Arquivos Pdbs
    cout << "Done!\n";
}//Fim do main


