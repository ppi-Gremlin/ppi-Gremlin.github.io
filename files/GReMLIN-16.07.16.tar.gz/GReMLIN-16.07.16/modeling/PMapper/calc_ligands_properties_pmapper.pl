#!/usr/bin/perl

use strict;
use warnings;
use Getopt::Long;

my $data_path; # The data path which contains all the files used in this program.

my $help;

my $chemaxon_path = "/opt/Chemaxon"; # Chemaxon path.

$| = 1;

#receiving Params
GetOptions(	'p=s' => \$data_path,
			'chemaxon=s' => \$chemaxon_path,							
			'h|help|?' => \$help
);

main();

sub main
{
	print "\n";
	# Validate the parameters received.
	validate_parameters();
	
	# Start processing: create pdb files containing only atoms and heteroatoms.
	init_processing();
		
	print "$0 finished successfully.\n\n";		
}

sub validate_parameters()
{
	my $req_params_exists = 1;
	my $input_exists = 1;
	
	if ( defined $help ) 
	{
		print usage();
		exit;
	}
	
	unless ( defined $data_path ) 
	{
		$req_params_exists = 0;
	}
	
	if ($req_params_exists) 
	{
		unless ( -d $data_path ) 
		{
			print STDERR "$data_path doesn't exist.\n";
			$input_exists = 0;
		}
	}
	
	unless ($req_params_exists) 
	{		
		print usage();
		exit;
	}

	unless ($input_exists) 
	{
		print STDERR "Program execution aborted.\n";
		exit;
	}	
	
	unless ( -d $chemaxon_path )
	{
		print STDERR "Chemaxon path '$chemaxon_path' doesn't exist.\n";
		exit;
	}
}

sub usage
{
	my $usage = <<FOO;
Usage:
	perl $0 -p project_name\n
FOO
	return $usage; 
}

sub init_processing
{
	print "Calculating atoms properties for each ligand by passing a .mol file to pmapper...\n";
	
	my $pdb_path = "$data_path/ligands_mol";
	my @pdb_list = get_file_list($pdb_path);	
	
	# If the path doesn't exist, create the directory
	my $out_path = "$data_path/ligand_pmapper";
	create_directory($out_path);
	
	# Export the Chemaxon license.
	$ENV{"CHEMAXON_LICENSE_URL"} = "$chemaxon_path/license.cxl";
	
	for my $file (@pdb_list)
	{		
		my $pdb_id = substr($file,0,index($file,".mol"));		
		
		calculate_atoms_properties("$pdb_path/$file","$out_path/$pdb_id.pmapper");
	}	
}

# Recover the pdbs file in the defined path. 
# Params: 
#	- $path: the path where the .pdb files are located.
sub get_file_list
{
	my $path = $_[0];
	
	opendir(DIR, $path) or die $!;
	
	my @pdb_list = ();
	
	while (my $file = readdir(DIR)) {
		
		if ( $file =~ m/.mol/ ) 
		{
	         push(@pdb_list, $file);  
		}	
		
	}
	
	closedir(DIR);
	
	return (sort @pdb_list);
}

# Try to create a new directory with the name passed as parameter. 
sub create_directory
{
	my $dir_name = $_[0];
	
	unless (-d $dir_name) 
	{
		mkdir($dir_name) or die "$dir_name cannot be created: $!\n";
	}
}

sub calculate_atoms_properties
{
	my $file = $_[0];
	my $pmapper_file = $_[1];
	
	print "$pmapper_file created.\n";
	
	system("$chemaxon_path/bin/pmapper -c pharma-calc.xml $file > $pmapper_file");
}