/*----------------------------------------
* Depertamento de Informática - UFV
* Charles Abreu Santana - Mat: 87858
* Ultima modificação: 24/05/2016
*-----------------------------------------*/
/* Este programa exclu linhas de Hidrogenio presentes em um arquivo pdb.
* Alem disso, cria novos arquivos com nomes em uppercase
*/
#include<iostream>
#include<fstream>
#include<stdio.h>
#include<string>
#include<vector>
#include<sstream>
#include <ctype.h>

using namespace std;

string getTag(string str);

int main(int argc, char* argv[]){

    if(argc < 3){
        cout<<"Entre com os parâmetros corretamente!"<<endl;
        cout<<"<lista com o caminho dos arquivos .pdb> <Diretorio de saida>"<<endl;
        return 0;
    }
    cout<<"Retirando Hidrogenios dos arquivos pdb ...\n";

    string infilePdbIds = argv[1];
    string outDir = argv[2];

    fstream arquivo_pdbids(infilePdbIds.c_str());
    string nome_do_arquivo;
    string lineInPdb;
    arquivo_pdbids >> lineInPdb;
    cout << "Lendo lista de arquivos ...\n";
    while(!arquivo_pdbids.eof()){ // le lista de pdb ids
        ifstream entrada;
        ofstream saida;
        string nomeDoArquivo;
        entrada.open(lineInPdb.c_str());
        //Convertendo pdbID de minusculo pra maiusculo
        for(int i = (lineInPdb.size()-8); i<(lineInPdb.size()-4); i++){
            lineInPdb[i] = toupper(lineInPdb[i]);
        }
        nomeDoArquivo = outDir + "/" + lineInPdb.substr((lineInPdb.size()-8), (lineInPdb.size()-4));
        saida.open(nomeDoArquivo.c_str());

        char linhaPdb[256];
        string linhaPdb_str;
        entrada.getline(linhaPdb, 256);
        while(!entrada.eof()){
            linhaPdb_str = linhaPdb;
            string tag = getTag(linhaPdb_str);
            if((tag.compare("HETATM") == 0) || (tag.compare("ATOM") == 0)){
                string atom = linhaPdb_str.substr(76,2);
                if(atom.compare(" H") != 0){
                    saida << linhaPdb << "\n";
                }
            } else{
                saida << linhaPdb << "\n";
            }
            entrada.getline(linhaPdb, 256);
        }

        entrada.close();
        saida.close();

        arquivo_pdbids >> lineInPdb;
    }//Fim do while: achou o fim da lista de Arquivos Pdbs
    cout << "Done!\n";
}//Fim do main

string getTag(string str){
    string tag = "";
    for(int i=0; i < str.size(); i++){
        if(str[i] == ' '){
            return tag;
        } else{
            tag.push_back(str[i]);
        }
    }
}


