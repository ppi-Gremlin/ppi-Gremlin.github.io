// ******************************************************
// *		Grupo de Bioinformatica Estrutural			*
// *		UFMG/DCC									*
// *   ----------------------------------------------	*
// *													*
// * Douglas Eduardo Valente Pires - dpires@dcc.ufmg.br	*
// * www.dcc.ufmg.br/~dpires							*
// * Ultima Modificacao :: 11/01/2009					*
// *   ----------------------------------------------	*
// * "With great power, comes great responsibility."	*
// ******************************************************

//-------------------------------------------------------
// Programa responsavel pelo calculo da triangulacao de
// Delaunay
//-------------------------------------------------------

#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/Triangulation_3.h>

//11111111111
#include <CGAL/Delaunay_triangulation_3.h>
#include <CGAL/Triangulation_hierarchy_3.h>
//11111111111

#include <stdio.h>

#include <cassert>
#include <vector>
#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <stdio.h>
#include <list>

using namespace std;

typedef CGAL::Exact_predicates_inexact_constructions_kernel K;

typedef CGAL::Triangulation_3<K>      Triangulation;

// typedef Triangulation::Finite_vertices_iterator Finite_vertices_iterator;
// typedef Triangulation::Finite_edges_iterator Finite_edges_iterator;
typedef Triangulation::Finite_facets_iterator Finite_facets_iterator;
typedef Triangulation::Finite_cells_iterator Finite_cells_iterator;
typedef Triangulation::Simplex        Simplex;
typedef Triangulation::Locate_type    Locate_type;
typedef Triangulation::Point          Point;

//11111111111
typedef CGAL::Triangulation_vertex_base_3<K>             Vb;
typedef CGAL::Triangulation_hierarchy_vertex_base_3<Vb>  Vbh;
typedef CGAL::Triangulation_data_structure_3<Vbh>        Tds;
typedef CGAL::Delaunay_triangulation_3<K,Tds>            Dt;
typedef CGAL::Triangulation_hierarchy_3<Dt>              Dh;

typedef Dh::Finite_vertices_iterator Finite_vertices_iterator;
typedef Dh::Finite_edges_iterator Finite_edges_iterator;
typedef Dh::Vertex_handle            Vertex_handle;
typedef Dh::Point                    Point;
//11111111111

int main(int argc, char **argv){

	FILE *infile;				// Fluxo ligado ao arquivo de entrada
	FILE *coordfile;			// Fluxo ligado ao arquivo de coordenadas
	char coordfile_path[150]; 	// Caminho para arquivo de coordenadas

	ofstream outfile;			// Fluxo ligado ao arquivo de saida
	char outfile_path[150]; 	// Caminho para arquivo de saida

	// Verifica se sintaxe de execucao esta correta
	if(argc != 2){
		cout << "************************************************************";
		cout << "\nSintaxe de execucao:\n   ./calculaDT <inFile>\n";
		cout << "Onde <inFile> possui os arquivos .coord para calculo do Delaunay Tesselation.\n";
		cout << "************************************************************\n";
		exit(1);
	}

	// Tenta abrir arquivo de entrada
	if(!(infile = fopen(argv[1],"r"))){
		cout << "Nao foi possivel abrir o arquivo de entrada: " << argv[1] << endl;
		cout << "O programa sera encerrado.\n";
		exit(1);
    }

	// Lista de pontos
	std::list<Point> pointList;

	// Le arquivo de entrada abre arquivo de coordenadas e gera-se o alphaShape
	while(!feof(infile)){
		// Le nome do arquivo de entrada
		fscanf(infile, "%s", coordfile_path);

		// Limpa a lista de pontos
		pointList.clear();

		// Tenta abrir arquivo de coordenadas
		if(!(coordfile = fopen(coordfile_path,"r"))){
			cout << "Nao foi possivel abrir o arquivo de coordenadas: " << coordfile_path << endl;
			cout << "O programa sera encerrado.\n";
			exit(1);
		}

		int counter = 0;
		float x,y,z;

		while(!feof(coordfile)){
			fscanf(coordfile, "%f %f %f\n", &x, &y, &z);
			// Le os pontos e insere no inicio da lista
			pointList.push_front(Point(x,y,z));
			counter++;
		}
		fclose(coordfile);

//		Triangulation T(pointList.begin(), pointList.end());
		//11111111111
		Dh T(pointList.begin(), pointList.end());
		//11111111111

// 		std::cout << T.number_of_edges() << " Edges" << std::endl;

		sprintf(outfile_path,"%s%s", coordfile_path,".dt");

		// Tenta abrir arquivo de saida
		outfile.open(outfile_path);
		if(!outfile.is_open()){
			cout << "Nao foi possivel abrir o arquivo de saida: " << outfile_path << endl;
			cout << "O programa sera encerrado.\n";
			exit(1);
		}

		for (Finite_edges_iterator eit = T.finite_edges_begin(); eit != T.finite_edges_end(); ++eit){

			outfile << (*eit).first->vertex(0)->point() << "," << (*eit).first->vertex(1)->point()  << "," << (*eit).first->vertex(2)->point() << "," << (*eit).first->vertex(3)->point() << "," << (*eit).second <<"," << (*eit).third <<std::endl;
		}
		outfile.close();
	}
	fclose(infile);

	return 0;
}
