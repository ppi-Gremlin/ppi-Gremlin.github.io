#!/usr/bin/perl -w 

# *******************************************************
# *		Grupo de Bioinformatica Estrutural				*
# *		UFMG/DCC										*
# *   ----------------------------------------------	*
# *														*
# * Douglas Eduardo Valente Pires - dpires@dcc.ufmg.br	*
# * www.dcc.ufmg.br/~dpires								*
# * Ultima Modificacao :: 05/04/2010					*
# *   ----------------------------------------------	*
# *******************************************************

# Arquivo com a constantes utilizadas

use constant contatos_nivel_atomico => 0;	# Paradigma de definicao de contatos - entre residuos ou atomos
											# 1 - atom-atom
											# 0 - res-res

# Definicao de constantes
use constant PI => 3.14159265;			# Pi
use constant k => 20000;				# Funcao degrau suavizada
use constant max_wire => 70;			# Espessura max de aresta
use constant min_wire => 10;			# Espessura min de aresta
use constant cutoff_init_1 => 0.0;		# Limite cutoff inferior
use constant cutoff_init_2 => 0.0;		# Inicio cutoff superior
use constant gera_pra_um_residuo => 0;	# Geracao de arestas emtorno de um unico residuo

use constant menorDist => 1;			# Consideracao para gerar arestas - menor/maior distancia
										# 0 -> primeiro na sequencia
										# 1 -> menor distancia

use constant reenumeraPDB => 0;			# Opcao de reenumeracao de PDBs de entrada

use constant cg_all_back_side => 2;		# Consideracao para calcular o centro geometrico do residuo
										# 0 -> todos os atomos
										# 1 -> somente os do backbone
										# 2 -> somente os da cadeia lateral

use constant ca_cg_ou_minDist => 0;		# Consideracao distancia no parser Ad -> Voro3d

use constant consider_U_as_hetatom => 0;# Considera residuos U como heteroatomos

use constant ADCGAL_prune => 7.0; 		# Contantes relativas a geracao de arquivos AD
#use constant ADCGAL_prune => 18.0;

#use constant ADCGAL_cutoff => 2;		# zero = 0.000000001
use constant ADCGAL_cutoff => 0.000000001;
#use constant ADCGAL_del_or_ad => 0;	# Constante decide sobre a consideracao dos arquivos
use constant ADCGAL_del_or_ad => 1;										# gerados pelo ADCGAL
										# 0 -> .AD
										# 1 -> .del

use constant gera_arquivos_oclusao => 1;# Indica geracao de arquivos ADCGAL-like com 
										# contatos oclusos, nao oclusos e o total.

use constant fator_oclusao => 4;

# Usadas para gerar script Rasmol
use constant colour =>"yellow";
use constant resColour =>"orange";

return 1
