#!/usr/bin/perl -w

# *******************************************************
# *		Grupo de Bioinformatica Estrutural				*
# *		UFMG/DCC										*
# *   ----------------------------------------------	*
# *														*
# * Douglas Eduardo Valente Pires - dpires@dcc.ufmg.br	*
# * www.dcc.ufmg.br/~dpires								*
# * Ultima Modificacao :: 11/01/2009					*
# *   ----------------------------------------------	*
# * "With great power, comes great responsibility."		*
# *******************************************************

# Programa extrai coordenadas de arquivos pdb contidos no
# arquivo de entrada. Gera um arquivo de coordenadas para
# cada arquivo de entrada, com a extensao .coord

# Coordenadas negativas sao eliminadas somando o valor
# daquela com maior modulo a ela e as demais.
# Isso nao altera a disposicao relativa dos atomos.

sub trim;

$inFile = $ARGV[0];		# Arquivo de entrada

#------------------------------------------------------------------------------------#
if(scalar(@ARGV) < 1){
	print "#####################################################################\n";
	print " SINTAXE:\n\tperl extrai_coordenadas.pl <in_pdbIDs>\n";
	print " Script extrai coordenadas de arquivos pdb.\n";
	print "#####################################################################\n";
	exit;
}
#------------------------------------------------------------------------------------#
# Cria fluxo ligado ao arquivo de entrada (leitura)
open(INFILE,"<$inFile") or die "$!Erro ao abrir: $inFile\n";
@IDs = <INFILE>;		# Armazena o arquivo em um arranjo
close INFILE;			# Fecha fluxo ligado ao arquivo
#------------------------------------------------------------------------------------#

# Extrai informacoes sobre as posicoes dos atomos
foreach $pdbID (@IDs) {

	chomp($pdbID);

	print $pdbID, "\n";

	# Cria fluxo ligado ao arquivo pdb (leitura)
	open(PDB,"<$pdbID") or die "$!Erro ao abrir: $pdbID\n";
	@pdbFile = <PDB>;		# Armazena o arquivo em um arranjo
	close PDB;			# Fecha fluxo ligado ao arquivo

	$logFile = substr($pdbID,0,length($pdbID)-3)."log";
	open(LOG,">$logFile") or die "$!Erro ao abrir: $logFile\n";

	$counter=0;

	$minCoord = 0.0000;
	$coord_x = 0.0000;
	$coord_y = 0.0000;
	$coord_z = 0.0000;

	foreach $line (@pdbFile) {

		chomp($line);

		# Cordenadas de atomos ou heteroatomos
		if( ((length($line) >= 4 and substr($line,0,4) eq "ATOM") or (length($line) >= 6 and substr($line,0,6) eq "HETATM"))
			and (length($line) >= 16 and substr(trim(substr($line,12,4)),0,1) ne "H")
		){

			$coord_x = trim(substr($line,30,8));
			$coord_y = trim(substr($line,38,8));
			$coord_z = trim(substr($line,46,8));
			
			$out[$counter] = sprintf  '%.3f%s%.3f%s%.3f%s', $coord_x, " ", $coord_y, " ", $coord_z, "\n";

			if($coord_x < $minCoord){
				$minCoord = $coord_x;
			}
			if($coord_y < $minCoord){
				$minCoord = $coord_y;
			}
			if($coord_z < $minCoord){
				$minCoord = $coord_z;
			}
			$counter++;
		}
	}

	printf LOG '%.3f%s', $minCoord, "\n";

	if($minCoord < 0.000){

		$counter = 0;
		$minCoord *= -1.0000;
		foreach $line (@pdbFile) {

			chomp($line);

			# Cordenadas de atomos ou heteroatomos
			if((length($line) >= 4 and substr($line,0,4) eq "ATOM") or (length($line) >= 6 and substr($line,0,6) eq "HETATM")){
	
				$coord_x = trim(substr($line,30,8));
				$coord_y = trim(substr($line,38,8));
				$coord_z = trim(substr($line,46,8));
				
				$out[$counter] = sprintf  '%.3f%s%.3f%s%.3f%s',
					($coord_x+$minCoord+1.000), " ", ($coord_y+$minCoord+1.000), " ", ($coord_z+$minCoord+1.000), "\n";
	
				$counter++;
			}
		}
	}

	# Imprime arquivos de saida
	$outFile = substr($pdbID,0,length($pdbID)-3)."coord";

	# Cria fluxo ligado ao arquivo de saida (escrita)
	open(OUTFILE,">$outFile") or die "$!Erro ao abrir: $outFile\n";

	for($i=0; $i<$counter; $i++){
		print OUTFILE $out[$i];
	}

	close OUTFILE;
	close LOG;
}
#------------------------------------------------------------------------------------#
# Fim do programa
exit;

# Elimina caracteres brancos nas extremidade de uma string
sub trim($){
	my $string = shift;
	$string =~ s/^\s+//;
	$string =~ s/\s+$//;
	return $string;
}
