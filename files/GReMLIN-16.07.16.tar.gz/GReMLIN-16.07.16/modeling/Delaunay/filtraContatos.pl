#!/usr/bin/perl -w

use strict;
use warnings;

# *******************************************************
# *		Grupo de Bioinformatica Estrutural				*
# *		UFMG/DCC										*
# *   ----------------------------------------------	*
# *														*
# * Douglas Eduardo Valente Pires - dpires@dcc.ufmg.br	*
# * www.dcc.ufmg.br/~dpires								*
# * Ultima Modificacao :: 15/01/2011					*
# *   ----------------------------------------------	*
# * "With great power, comes great responsibility."		*
# *******************************************************

sub trim;
sub eh_atomo_de_residuo;
sub distance;

my $inFileDT = $ARGV[0];		# Arquivo de entrada
my $inFileMOL = $ARGV[1];  		# Arquivo de entrada
my $map = $ARGV[2];  			# Arquivo de saida

use constant MAX_DIST => 6.0;

#------------------------------------------------------------------------------------#
if(scalar(@ARGV) != 3){
	print "#####################################################################\n";
	print " SINTAXE:\n\tperl filtraContatos.pl <infiles.DT.sorted> <infiles.mol> <labels.map>\n";
	print "#####################################################################\n";
	exit;
}
#------------------------------------------------------------------------------------#
# Cria fluxo ligado ao arquivo de entrada (leitura)
open(INFILE_DT,"<$inFileDT") or die "$!Erro ao abrir: $inFileDT\n";
my @filesDT = <INFILE_DT>;		# Armazena o arquivo em um arranjo
close INFILE_DT;				# Fecha fluxo ligado ao arquivo

open(TO_DELETE,">deleteDNA.sh") or die "$!Erro ao abrir: >deleteDNA.sh\n";

open(INFILE_MOL,"<$inFileMOL") or die "$!Erro ao abrir: $inFileMOL\n";
my @filesMOL = <INFILE_MOL>;    # Armazena o arquivo em um arranjo
close INFILE_MOL;           	# Fecha fluxo ligado ao arquivo
#------------------------------------------------------------------------------------#
my %proteinVertexLabel;

open(MAP,"<proteinVertexLabel.map") or die "$!Erro ao abrir: proteinVertexLabel.map\n";
my @map = <MAP>;				# Armazena o arquivo em um arranjo
close MAP;

open(MAP,">$map") or die "$!Erro ao abrir: $map\n";
print MAP "noCharacter_0\n";
print MAP "hydrophobic_1\n";
print MAP "donnor_2\n";
print MAP "acceptor_3\n";
print MAP "aromatic_4\n";
print MAP "positive_5\n";
print MAP "negative_6\n";

foreach my $line (@map){
	chomp($line);

	my @tokens = split(/\s+/, $line);
	if($tokens[0] eq "hydrophobic"){
		$proteinVertexLabel{$tokens[1]} = 1;
	} if($tokens[0] eq "donnor"){
		$proteinVertexLabel{$tokens[1]} = 2;
	} if($tokens[0] eq "acceptor"){
		$proteinVertexLabel{$tokens[1]} = 3;
	} if($tokens[0] eq "aromatic"){
		$proteinVertexLabel{$tokens[1]} = 4;
	} if($tokens[0] eq "positive"){
		$proteinVertexLabel{$tokens[1]} = 5;
	} if($tokens[0] eq "negative"){
		$proteinVertexLabel{$tokens[1]} = 6;
	} 
}
#------------------------------------------------------------------------------------#
my %hash_chain;
my %selected;
my %het;
my @atomName;
my @resName;
my %mapAtomName;
my %mapAtomNum;
my $mapCounter = 0;
my $mapCounterAtom = 0;
my $mapCounterLabel = 7;
my @edge;

foreach my $file (@filesDT){
	chomp($file);
	my @tokens = split(/\./, $file);
	$hash_chain{$tokens[0]} = $file;
}

foreach my $file (@filesMOL){
	undef %selected;	undef @atomName;	undef @resName;		undef %het;		undef %mapAtomNum;
	$mapCounterAtom = 0;

	chomp($file);
	my @tokens = split(/_/, $file);
	my $hetIndex = $tokens[2];
	my @tokens2 = split(/\./, $file);
	my $dt_file = $tokens2[0].".".$tokens2[1];
	my $pmapper_file = $tokens2[0].$tokens2[1].$tokens2[2].$tokens2[3];

	if($file =~ m/model/){
		$dt_file .= ".".$tokens2[2];
		$pmapper_file = ".".$tokens2[4];
	}
	
	open(PMAPPER, "/scratch/curso2011/data/pdb/pmapper/$file.pmapper") or die "$!Erro ao abrir: /scratch/curso2011/data/pdb/pmapper/$file.pmapper\n";
	my @pmapper = <PMAPPER>;
	close PMAPPER;

	open(DT,"</scratch/curso2011/data/pdb/chain/$dt_file.filtered.DT.sorted") or die "$!Erro ao abrir: /scratch/curso2011/data/pdb/chain/$dt_file.filtered.DT.sorted\n";
	my @DT = <DT>;			# Armazena o arquivo em um arranjo
	close DT;				# Fecha fluxo ligado ao arquivo

	open(PDB,"</scratch/curso2011/data/pdb/chain/$dt_file.pdb") or die "$!Erro ao abrir: /scratch/curso2011/data/pdb/chain/$dt_file.pdb\n";
	my @pdb = <PDB>;		# Armazena o arquivo em um arranjo
	close PDB;				# Fecha fluxo ligado ao arquivo

	# ------------------------------------------------------------------------------------------------------------
	my @type_pmapper = split(/;/, $pmapper[0]);
	chomp($type_pmapper[$#type_pmapper]);

# 	foreach my $aaa (@type_pmapper){
# 		print "_", $aaa, "_\n";
# 	}
# 
# 	print @type_pmapper, "\n" ;
# 	print $#type_pmapper, "\n";
# 	print @pmapper, "\n";

	my $counterHetNum = 0;
	my @coord_x;	undef @coord_x;
	my @coord_y;	undef @coord_y;
	my @coord_z;	undef @coord_z;
	# ------------------------------------------------------------------------------------------------------------
	foreach my $info (@pdb){
		chomp($info);
		if(length($info) >= 6 and (trim(substr($info,0,6)) eq "ATOM" or trim(substr($info,0,6)) eq "HETATM")){
			my $atomNumber = trim(substr($info, 6, 5));
			$atomName[$atomNumber] = trim(substr($info, 12, 4));
			$resName[$atomNumber] = trim(substr($info, 17, 3));
			my $resNumber = trim(substr($info, 22, 4));

			if($resNumber == $hetIndex and $resName[$atomNumber] ne "HOH"){
				$het{$atomNumber} = $counterHetNum;
				$counterHetNum++;
			}

			$coord_x[$atomNumber] = trim(substr($info,30,8));
			$coord_y[$atomNumber] = trim(substr($info,38,8));
			$coord_z[$atomNumber] = trim(substr($info,46,8));

			if(!defined($mapAtomName{$atomName[$atomNumber]})){
				$mapAtomName{$atomName[$atomNumber]} = $mapCounter;
				$mapCounter++;
			}
		}
	}
	# ------------------------------------------------------------------------------------------------------------
	foreach my $contact (@DT){
		chomp($contact);
		@edge = split(/\s+/, $contact);

		if(defined($het{$edge[0]})){
			if(defined($het{$edge[1]}) or eh_atomo_de_residuo($resName[$edge[1]])){
				$selected{$edge[0]} = 1;
				$selected{$edge[1]} = 1;
			}
		}
		elsif(defined($het{$edge[1]})){
			if(defined($het{$edge[0]}) or eh_atomo_de_residuo($resName[$edge[0]])){
				$selected{$edge[0]} = 1;
				$selected{$edge[1]} = 1;
			}
		}
	}
	# ------------------------------------------------------------------------------------------------------------
	my $outfile = "/scratch/curso2011/data/pdb/graphs/".$file.".graph";
	open(OUTFILE,">$outfile") or die "$!Erro ao abrir: $outfile\n";
	open(OUTFILE_MAP,">$outfile.vertexMap") or die "$!Erro ao abrir: $outfile.vertexMap\n";

	my @selected_sorted = sort {$a <=> $b} keys %selected;

	print OUTFILE "t # \n";
	foreach my $vertex (@selected_sorted){
		chomp($vertex);
		my $vertexLabel = -1;

		# Atomo de proteina
		if(!defined($het{$vertex})){
			my $key = $resName[$vertex]."_".$atomName[$vertex];

			if(defined($proteinVertexLabel{$key})){
				$vertexLabel = $proteinVertexLabel{$key};
			}
			else{
				$vertexLabel = 0
			}
		}
		else{
			if(!defined($proteinVertexLabel{$type_pmapper[$het{$vertex}]})){
				$proteinVertexLabel{$type_pmapper[$het{$vertex}]} = $mapCounterLabel;
				print MAP $type_pmapper[$het{$vertex}],"_", $mapCounterLabel, "\n";
				$mapCounterLabel++;
			}
			$vertexLabel = $proteinVertexLabel{$type_pmapper[$het{$vertex}]};
		}

		if(!defined($mapAtomNum{$vertex})){
			$mapAtomNum{$vertex} = $mapCounterAtom;
			print OUTFILE_MAP $mapAtomNum{$vertex}, "_", $vertex, "\n";
			$mapCounterAtom++;
		}

		print OUTFILE "v ", $mapAtomNum{$vertex}, " ", $vertexLabel, "\n";
	}

	my $flag_ok = 0;

	foreach my $contact (@DT){
		chomp($contact);
		my @edge = split(/\s+/, $contact);
		my $edgeLabel = -1;

		if($selected{$edge[0]} and $selected{$edge[1]}){
			if(distance($coord_x[$edge[0]],$coord_y[$edge[0]],$coord_z[$edge[0]],
						$coord_x[$edge[1]],$coord_y[$edge[1]],$coord_z[$edge[1]]) 
				<= MAX_DIST){
				# Ligante-Ligante
				if(defined($het{$edge[0]}) and defined($het{$edge[1]})){
					$edgeLabel = 0;
				}
				# Proteina-Proteina
				elsif(!defined($het{$edge[0]}) and !defined($het{$edge[1]})){
					$edgeLabel = 1;
				}
				# Proteina-Ligante
				else{
					$edgeLabel = 2;
					$flag_ok = 1;
				}		
				print OUTFILE "e ", $mapAtomNum{$edge[0]}, " ", $mapAtomNum{$edge[1]}, " $edgeLabel\n";
			}
		}
	}
	close OUTFILE;
	close OUTFILE_MAP;

	if(!$flag_ok){
		print TO_DELETE "rm $outfile\n";
	}
	# ------------------------------------------------------------------------------------------------------------

	print "$outfile\n";
}
close MAP;
close TO_DELETE;
#------------------------------------------------------------------------------------#
# Fim do programa
exit;

# Elimina caracteres brancos nas extremidade de uma string
sub trim($){
	my $string = shift;
	$string =~ s/^\s+//;
	$string =~ s/\s+$//;
	return $string;
}

# Verifica se resName eh de uma residuo proteico
sub eh_atomo_de_residuo{
	my $res_name = shift;

	if( $res_name eq "ALA" or $res_name eq "VAL" or $res_name eq "LEU" or $res_name eq "GLY" or
		$res_name eq "SER" or $res_name eq "TRP" or $res_name eq "THR" or $res_name eq "GLN" or
		$res_name eq "GLU" or $res_name eq "CYS" or $res_name eq "ARG" or $res_name eq "PRO" or
		$res_name eq "ASP" or $res_name eq "PHE" or $res_name eq "ILE" or $res_name eq "HIS" or
		$res_name eq "ASN" or $res_name eq "MET" or $res_name eq "TYR" or $res_name eq "LYS"
	){
		return 1;
	}
	return 0;
}

# Calcula a distancia Euclidiana de dois pontos no espaco
sub distance{
	my($x1,$y1,$z1,$x2,$y2,$z2) = @_;
	my $distance;

	$distance = sqrt(($x1-$x2)**2 + ($y1-$y2)**2 + ($z1-$z2)**2);
	return $distance;
}

