#!/usr/bin/perl -w

use strict;
use warnings;

# *******************************************************
# *		Grupo de Bioinformatica Estrutural				*
# *		UFMG/DCC										*
# *   ----------------------------------------------	*
# *														*
# * Douglas Eduardo Valente Pires - dpires@dcc.ufmg.br	*
# * www.dcc.ufmg.br/~dpires								*
# * Ultima Modificacao :: 14/01/2009					*
# *   ----------------------------------------------	*
# * "With great power, comes great responsibility."		*
# *******************************************************

# Programa extrai contatos a partir das informacoes geradas via
# Delaunay.
#
# A saida gerada deve ser ordenada via: 'sort -u'

use FindBin;
use lib $FindBin::Bin;

use funcoes;
use constantes;

sub eh_atomo_de_residuo;

my $inFileDT = $ARGV[0];		# Arquivo de entrada
my $inFileLOG = $ARGV[1];  		# Arquivo de entrada
my $inFilePDB = $ARGV[2];     	# Arquivo de entrada

#------------------------------------------------------------------------------------#
if(scalar(@ARGV) != 3){
	print "#####################################################################\n";
	print " SINTAXE:\n\tperl extrai_contatos.pl <infiles.dt.formatted> <infiles.log> <infile.pdb>\n";
	print " Script extrai contatos a parti de informacoes geradas via DT.\n";
	print "#####################################################################\n";
	exit;
}
#------------------------------------------------------------------------------------#
# Cria fluxo ligado ao arquivo de entrada (leitura)
open(INFILE_DT,"<$inFileDT") or die "$!Erro ao abrir: $inFileDT\n";
my @filesDT = <INFILE_DT>;		# Armazena o arquivo em um arranjo
close INFILE_DT;			# Fecha fluxo ligado ao arquivo

open(INFILE_LOG,"<$inFileLOG") or die "$!Erro ao abrir: $inFileLOG\n";
my @filesLOG = <INFILE_LOG>;   # Armazena o arquivo em um arranjo
close INFILE_LOG;           # Fecha fluxo ligado ao arquivo

open(INFILE_PDB,"<$inFilePDB") or die "$!Erro ao abrir: $inFilePDB\n";
my @filesPDB = <INFILE_PDB>;      # Armazena o arquivo em um arranjo
close INFILE_PDB;           # Fecha fluxo ligado ao arquivo
#------------------------------------------------------------------------------------#
if(scalar(@filesDT) != scalar(@filesLOG) or scalar(@filesLOG) != scalar(@filesPDB) or scalar(@filesDT) != scalar(@filesPDB)){
	print "\nNumero incorreto de arquivos.\nO programa sera finalizado.";
	exit;
}

#my %resIndex;
my %atomIndex;

#------------------------------------------------------------------------------------#
# Extrai informacoes sobre as posicoes dos atomos
for(my $k=0; $k<scalar(@filesDT); $k++){

	chomp($filesDT[$k]);	my $dtFile = $filesDT[$k];
	chomp($filesLOG[$k]);	my $logFile = $filesLOG[$k];
	chomp($filesPDB[$k]);	my $pdbFile = $filesPDB[$k];

	print "$pdbFile\n";

	#undef %resIndex;
	undef %atomIndex;

	# Cria fluxo ligado ao arquivo dt (leitura)
	open(DT,"<$dtFile") or die "$!Erro ao abrir: $dtFile\n";
	my @dt = <DT>;		# Armazena o arquivo em um arranjo
	close DT;			# Fecha fluxo ligado ao arquivo

	# Cria fluxo ligado ao arquivo log (leitura)
	open(LOG,"<$logFile") or die "$!Erro ao abrir: $logFile\n";
	my @log = <LOG>;	# Armazena o arquivo em um arranjo
	close LOG;			# Fecha fluxo ligado ao arquivo

	# Cria fluxo ligado ao arquivo pdb (leitura)
	open(PDB,"<$pdbFile") or die "$!Erro ao abrir: $pdbFile\n";
	my @pdb = <PDB>;	# Armazena o arquivo em um arranjo
	close PDB;			# Fecha fluxo ligado ao arquivo

	chomp($log[0]);

	for(my $i=0; $i<scalar(@pdb); $i++){
		my $line = $pdb[$i];
		chomp($line);

		# Cordenadas de atomos
		if(length($line) >= 7 and (trim(substr($line,0,6)) eq "ATOM" or trim(substr($line,0,6)) eq "HETATM")){

			my $atom_ind = trim(substr($line,6,5));

			my $coord_x = trim(substr($line,30,8));
			my $coord_y = trim(substr($line,38,8));
			my $coord_z = trim(substr($line,46,8));


			my $logValue = trim($log[0])*(-1.000);

			my $x = ($coord_x);
			my $y = ($coord_y);
			my $z = ($coord_z);

			if($logValue != 0.000){
				$x += $logValue+1.000;
				$y += $logValue+1.000;
				$z += $logValue+1.000;
			}

			my $aux = sprintf  '%.3f%s%.3f%s%.3f', $x, " ", $y, " ", $z;

			#$resIndex{$aux} = $atom_ind; #$res_ind;
			$atomIndex{$aux} = $atom_ind;
		}
	}

	# Imprime arquivos de saida
	my $outFileDT = substr($pdbFile,0,length($pdbFile)-3)."DT";
	# Cria fluxo ligado aos arquivos de saida (escrita)
	open(OUTFILE_DT,">$outFileDT") or die "$!Erro ao abrir: $outFileDT\n";

#------------------------------------------------------------------------------------#
	# Extrai contatos gerados pelo Delaunay Tesselation
	foreach my $info_dt (@dt){
		my @aux2 = split(/,/,$info_dt);
		my $coord1 = $aux2[$aux2[4]];
		my $coord2 = $aux2[$aux2[5]];

		#if(contatos_nivel_atomico == 0){
		#	if(!defined($resIndex{$coord1}) or !defined($resIndex{$coord2})){
		#		print $pdbFile,"\n";
		#	}
		#	elsif($resIndex{$coord1} ne $resIndex{$coord2}){
		#		print OUTFILE_DT $resIndex{$coord1}." ".$resIndex{$coord2}."\n";
		#	}
		#}
		#else{
			if(!defined($atomIndex{$coord1}) or !defined($atomIndex{$coord2})){
				print $pdbFile,"\n";
			}
			else{
				print OUTFILE_DT $atomIndex{$coord1}." ".$atomIndex{$coord2}."\n";
			}
		#}
	}
#------------------------------------------------------------------------------------#
	close OUTFILE_DT;
}
#------------------------------------------------------------------------------------#
# Fim do programa
exit;

# Verifica se resName eh de uma residuo proteico
sub eh_atomo_de_residuo{
	my $res_name = shift;

	if( $res_name eq "ALA" or $res_name eq "VAL" or $res_name eq "LEU" or $res_name eq "GLY" or
		$res_name eq "SER" or $res_name eq "TRP" or $res_name eq "THR" or $res_name eq "GLN" or
		$res_name eq "GLU" or $res_name eq "CYS" or $res_name eq "ARG" or $res_name eq "PRO" or
		$res_name eq "ASP" or $res_name eq "PHE" or $res_name eq "ILE" or $res_name eq "HIS" or
		$res_name eq "ASN" or $res_name eq "MET" or $res_name eq "TYR" or $res_name eq "LYS"
	){
		return 1;
	}
	return 0;
}
