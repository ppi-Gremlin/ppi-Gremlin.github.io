#!/usr/bin/perl -w 

# *******************************************************
# *		Grupo de Bioinformatica Estrutural				*
# *		UFMG/DCC										*
# *   ----------------------------------------------	*
# * Co-Orientador :: Carlos Silveira					*
# *														*
# * Douglas Eduardo Valente Pires - dpires@dcc.ufmg.br	*
# * www.dcc.ufmg.br/~dpires								*
# * Ultima Modificacao :: 27/12/2007					*
# *   ----------------------------------------------	*
# * "With great power, comes great responsibility."		*
# *******************************************************

# Arquivo com a implementacao das  subrotinas utilizadas

#----------------------------------------------------------------------------------------
# Recebe codigo de residuo de um caractere e retorna o equivalente de tres
sub res_cod1_to_res_cod3($){
	
	my $cod1 = shift;
		
	if($cod1 eq "A"){
		return "ALA";
	}
	elsif($cod1 eq "V"){
		return "VAL";
	}
	elsif($cod1 eq "L"){
		return "LEU";
	}
	elsif($cod1 eq "G"){
		return "GLY";
	}
	elsif($cod1 eq "S"){
		return "SER";
	}
	elsif($cod1 eq "W"){
		return "TRP";
	}
	elsif($cod1 eq "T"){
		return "THR";
	}
	elsif($cod1 eq "Q"){
		return "GLN";
	}
	elsif($cod1 eq "E"){
		return "GLU";
	}
	elsif($cod1 eq "C"){
		return "CYS";
	}
	elsif($cod1 eq "R"){
		return "ARG";
	}
	elsif($cod1 eq "P"){
		return "PRO";
	}
	elsif($cod1 eq "D"){
		return "ASP";
	}
	elsif($cod1 eq "F"){
		return "PHE";
	}
	elsif($cod1 eq "I"){
		return "ILE";
	}
	elsif($cod1 eq "H"){
		return "HIS";
	}
	elsif($cod1 eq "N"){
		return "ASN";
	}
	elsif($cod1 eq "M"){
		return "MET";
	}
	elsif($cod1 eq "Y"){
		return "TYR";
	}
	elsif($cod1 eq "K"){
		return "LYS";
	}
	return "ERRO";
}
#----------------------------------------------------------------------------------------
# Recebe codigo de residuo de tres caracteres e retorna o equivalente de um
sub res_cod3_to_res_cod1($){
	
	my $cod3 = shift;
		
	if($cod3 eq "ALA"){
		return "A";
	}
	elsif($cod3 eq "VAL"){
		return "V";
	}
	elsif($cod3 eq "LEU"){
		return "L";
	}
	elsif($cod3 eq "GLY"){
		return "G";
	}
	elsif($cod3 eq "SER"){
		return "S";
	}
	elsif($cod3 eq "TRP"){
		return "W";
	}
	elsif($cod3 eq "THR"){
		return "T";
	}
	elsif($cod3 eq "GLN"){
		return "Q";
	}
	elsif($cod3 eq "GLU"){
		return "E";
	}
	elsif($cod3 eq "CYS"){
		return "C";
	}
	elsif($cod3 eq "ARG"){
		return "R";
	}
	elsif($cod3 eq "PRO"){
		return "P";
	}
	elsif($cod3 eq "ASP"){
		return "D";
	}
	elsif($cod3 eq "PHE"){
		return "F";
	}
	elsif($cod3 eq "ILE"){
		return "I";
	}
	elsif($cod3 eq "HIS"){
		return "H";
	}
	elsif($cod3 eq "ASN"){
		return "N";
	}
	elsif($cod3 eq "MET"){
		return "M";
	}
	elsif($cod3 eq "TYR"){
		return "Y";
	}
	elsif($cod3 eq "LYS"){
		return "K";
	}
	return "ERRO";
}
#----------------------------------------------------------------------------------------
# Calcula o numero de arestas de um dado grafo
sub numArestas($){
	
	my $pdbID = shift;
	my (@pdb,$line,$numArestas);
	
	# Cria fluxo ligado ao arquivo de parametros (leitura)
	open(INFILE_1,"<graph/$pdbID") or die "$!Erro ao abrir: graph/$pdbID\n";
	@pdb = <INFILE_1>;			# Armazena o arquivo em um arranjo
	close INFILE_1;				# Fecha fluxo ligado ao arquivo
	
	$numArestas = 0;
	
	foreach $line (@pdb){
		if(substr($line,0,6) eq "CONECT"){	# Basta contar quantos CONECT existem
			$numArestas++;
		}
	}
	return $numArestas;
}
#----------------------------------------------------------------------------------------
# Calcula o numero de arestas de um dado grafo
sub numArestas2($){
	
	my $pdbID = shift;
	my (@pdb,$line,$numArestas);
	
	# Cria fluxo ligado ao arquivo de parametros (leitura)
	open(INFILE_1,"<tmp/$pdbID") or die "$!Erro ao abrir: tmp/$pdbID\n";
	@pdb = <INFILE_1>;			# Armazena o arquivo em um arranjo
	close INFILE_1;				# Fecha fluxo ligado ao arquivo
	
	$numArestas = 0;
	
	foreach $line (@pdb){
		if(substr($line,0,6) eq "CONECT"){	# Basta contar quantos CONECT existem
			$numArestas++;
		}
	}
	return $numArestas;
}
#----------------------------------------------------------------------------------------
# Avalia funcao logistica de aproximacao suavizada da funcao degrau
sub avaliaFuncao(@){
	my $x = shift;
	my $k = shift;
	my $c = shift;
	my $Fx;
	
	$Fx = 1/(1 + exp($k*($x-$c)));

	return $Fx;
}
#----------------------------------------------------------------------------------------
# Elimina caracteres brancos nas extremidade de uma string
sub trim($){
	my $string = shift;
	$string =~ s/^\s+//;
	$string =~ s/\s+$//;
	return $string;
}
#----------------------------------------------------------------------------------------
# Verifica se sring e' munerico
sub is_numeric($){
	my $string = shift;
	# Expressao regular
	if($string =~/^\d+$/){
		return 1;
	}
	return 0;
}
#----------------------------------------------------------------------------------------
# Verifica se existe opcao para calculo inter-estruturas. 
sub inter_structure($){
	
	my($parameter) = shift;		# Linha com o valor da opcao SECONDSTRUCT
	my($option);

	# Quebra a linha entre as virgulas
	my(@aux2) = split(/,/, $parameter);
	foreach $option (@aux2){
		# Indica calculo de distancias inter-estrutura(inter Helix)
		if(substr($option,0,11) eq "HELIX-inter"){
			return 1;
		}
		# Indica calculo de distancias inter-estrutura(inter Folha)
		elsif(substr($option,0,11) eq "SHEET-inter"){
			return 2;
		}
	}
	return 0;
}
#----------------------------------------------------------------------------------------
# Retorna a sequencia de residuos do PDB armazenada em um array
sub seq_residues(@){

	my($pdbID) = shift;
	my($line,$linha,$chain,$chainTemp,@resAux,$i,@pdb,$temp,$temp2);
	$i = 0;
	
	# Cria fluxo ligado ao arquivo de entrada (leitura)
	open(INFILE,"<pdb/$pdbID") or die "$!Erro ao abrir: pdb/$pdbID\n";
	@pdb = <INFILE>;				# Armazena o arquivo em um arranjo
	close INFILE;					# Fecha fluxo ligado ao arquivo
	
	$temp = 0;
	# pega a cadeia
	foreach $linha (@pdb){
		if(substr($linha,0,4) eq "ATOM"){
			$chain = substr($linha,21,1);
			last;
		}
	}

	foreach $line (@pdb){
		if(substr($line,0,4) eq "ATOM"){
			$chainTemp = substr($line,21,1);
			if($chainTemp eq $chain){
				$temp2 = substr($line,22,4);
				if($temp != $temp2){
					$resAux[$i] = substr($line,17,3);
					$temp = $temp2;
					$i++;
				}
			}
		}
	}

	return @resAux;
}
#----------------------------------------------------------------------------------------
# Retorna a sequencia de residuos do PDB armazenada em um array
sub seq_residues_tmp(@){

	my($pdbID) = shift;
	my($line,$linha,$chain,$chainTemp,@resAux,$i,@pdb,$temp,$temp2);
	$i = 0;
	
	# Cria fluxo ligado ao arquivo de entrada (leitura)
	open(INFILE,"<tmp/$pdbID") or die "$!Erro ao abrir: tmp/$pdbID\n";
	@pdb = <INFILE>;				# Armazena o arquivo em um arranjo
	close INFILE;					# Fecha fluxo ligado ao arquivo
	
	$temp = 0;
	# pega a cadeia
	foreach $linha (@pdb){
		if(substr($linha,0,4) eq "ATOM"){
			$chain = substr($linha,21,1);
			last;
		}
	}

	foreach $line (@pdb){
		if(substr($line,0,4) eq "ATOM"){
			$chainTemp = substr($line,21,1);
			if($chainTemp eq $chain){
				$temp2 = substr($line,22,4);
				if($temp != $temp2){
					$resAux[$i] = substr($line,17,3);
					$temp = $temp2;
					$i++;
				}
			}
		}
	}

	return @resAux;
}
#----------------------------------------------------------------------------------------
# Retorna nomes das cadeias de um arquivo pdb pela tag SEQRES
sub pega_cadeias_seqres(\@$){
	my(@pdbFile) = @{$_[0]};
	my($linha,@chains,$temp_chain,$c);
	$temp_chain="#";
	$c=0;
	
	foreach $linha (@pdbFile){
		if(substr($linha,0,6) eq "SEQRES"){
			if(substr($linha,11,1) ne $temp_chain){
				$temp_chain = substr($linha,11,1);
				$chains[$c] = $temp_chain;
				$c++;
			}
		}
	}
	# Retorna as cadeias segundo SEQRES
	return @chains;
}
#----------------------------------------------------------------------------------------
# Retorna nomes das cadeias diferentes de um arquivo pdb pela tag SEQRES
sub pega_cadeias_dif_seqres(\@$){
	my(@pdbFile) = @{$_[0]};
	my($linha,@chains,@chainDif,$temp_chain,$i,$j,$c,$r,$k,@nRes,@seqRes,$counter,$dif);
	$temp_chain="#";
	$c=0;
	
	for($i=0;$i<scalar(@pdbFile);$i++){
		$linha =$pdbFile[$i];
		if(substr($linha,0,6) eq "SEQRES"){
			if(substr($linha,11,1) ne $temp_chain){
				$nRes[$c] = substr($linha,14,3);
				$temp_chain = substr($linha,11,1);
				$chains[$c] = $temp_chain;
				# Extrai sequencia de residuos
				for($j=0;$j<$nRes[$c];$j++){
					if($j % 13 == 0){	# 13 residuos por linha
						$linha =$pdbFile[$i];
						$i++;
					}
					$seqRes[$c][$j] = substr($linha,19+4*($j % 13),3);
				}
				$i--;
				$c++;
			}
		}
	}

	$k=0;	
	$counter=0;
	# Seleciona as cadeias diferentes
	for($j=0;$j<scalar(@chains);$j++){
		$dif=1;
		for($i=$j;$i>0;$i--){
			if($nRes[$j] == $nRes[$i-1]){
				for($r=0;$r<$nRes[$j];$r++){
					if($seqRes[$j][$r] eq $seqRes[$i-1][$r]){
						$counter++;
					}
				}
				if($counter == $nRes[$j]){
					$dif = 0;
				}
				else{
					$dif = 1;
				}
				$counter = 0;
			}
		}
		if($dif){
			$chainDif[$k] = $chains[$j];
			$k++;
		}
	}
	# Retorna as cadeias diferentes segundo SEQRES
	return @chainDif;
}
#----------------------------------------------------------------------------------------
# Retorna nomes das cadeias de um arquivo pdb
sub pega_cadeias(\@$){
	my(@pdbFile) = @{$_[0]};
	my($linha, @chains, $c, $temp_chain);
	$c=0;
	$temp_chain="#";

	foreach $linha (@pdbFile){

		if((substr($linha,0,4) eq "ATOM") and (substr($linha,21,1) ne $temp_chain)){
			$temp_chain = substr($linha,21,1);
			$chains[$c] = $temp_chain;
			$c++;
		}
	}
	return @chains;
}
#----------------------------------------------------------------------------------------
# Retorna nomes das cadeias com sequencias diferentes de um arquivo pdb
sub pega_cadeias_dif(\@$){
	my(@pdbFile) = @{$_[0]};
	my($linha,@chains,@chains_dif,$c,$d,$e,$f,$dif,$nres,$temp_chain,$chain,@aux);
	$c=0;
	$temp_chain="#";
	
	foreach $linha (@pdbFile){
		if((substr($linha,0,4) eq "ATOM") and (substr($linha,21,1) ne $temp_chain)){
			$temp_chain = substr($linha,21,1);
			$chains[$c] = $temp_chain;
			$c++;
		}
	}
	# Retorna as cadeias com sequencias diferentes
	@chains_dif = chain_dif(\@chains, \@pdbFile);

	return @chains_dif;
}
#----------------------------------------------------------------------------------------
# Retorna a sequencia de residuos do PDB armazenada em um array de dada cadeia
sub chain_dif(\@$){

	my(@chains) = @{$_[0]};
	my(@pdbInfo) = @{$_[1]};
	
	my($line,$chainTemp,@chainDif,@resAux,$i,$j,$r,$counter,@nRes,$k,$temp,$temp2);
	$k=0;
	$temp = "###";

	for($j=0;$j<scalar(@chains);$j++){
		$i = 0;
		foreach $line (@pdbInfo){
			if(substr($line,0,4) eq "ATOM"){
				$chainTemp = substr($line,21,1);
				if($chainTemp eq $chains[$j]){
					$temp2 = substr($line,23,3);
					if($temp ne $temp2){
						$resAux[$j][$i] = substr($line,17,3);
						$temp = $temp2;
						$i++;
					}
				}
			}
		}
		# Numero de residuos da cadeia
		$nRes[$j] = $i;
	}
	$counter=0;
	# Seleciona as cadeias diferentes
	for($j=0;$j<scalar(@chains);$j++){
		$dif=1;
		for($i=$j;$i>0;$i--){
			if($nRes[$j] == $nRes[$i-1]){
				for($r=0;$r<$nRes[$j];$r++){
					if($resAux[$j][$r] eq $resAux[$i-1][$r]){
						$counter++;
					}
				}
				if($counter == $nRes[$j]){
					$dif = 0;
				}
				else{
					$dif = 1;
				}
				$counter = 0;
			}
		}
		if($dif){
			$chainDif[$k] = $chains[$j];
			$k++;
		}
	}

	return @chainDif;
}
#----------------------------------------------------------------------------------------
# Calcula a distancia Euclidiana de dois pontos no espaco
sub distance(@){

	my($x1,$y1,$z1,$x2,$y2,$z2) = @_;
	my $distance;
	
	$distance = sqrt(($x1-$x2)**2 + ($y1-$y2)**2 + ($z1-$z2)**2);
	return $distance;
}
#----------------------------------------------------------------------------------------
# Verifica se uma linha e' aceita mediante parametros de entrada
sub condicoes_aceitas(\@$){

	my($line) = ${$_[0]};			# Linha a sre avaliada
	my(@helix) = @{$_[1]};			# Conjunto de atomos pertencentes a alfa helices
	my(@sheet) = @{$_[2]};			# Conjunto de atomos pertencentes a folhas beta
	my(@turn) = @{$_[3]};			# Conjunto de atomos pertencentes a voltas ou loops
	my(@parameters) = @{$_[4]};		# Parametros de validacao das linhas

	# Flags das condicoes de aceitacao de uma linha/atomo
	my($SECONDSTR) = 0;
	my($ATOMTYPE) = 0; 
	my($CHAIN) = 0;
	my($OCCUP) = 0;
	my($ATOMRANGE) = 0;
	my($RESRANGE) = 0;
	my($ATOMNAME) = 0;
	my($RESNAME) = 0;
	
	$ATOMTYPE = atom_type_ok($line, $parameters[0]);
	$CHAIN = chain_ok($line, $parameters[1]);
	$OCCUP = occupancy_ok($line, $parameters[2]);
	$ATOMRANGE = atom_range_ok($line, $parameters[3]);
	$RESRANGE = res_range_ok($line, $parameters[4]);
	$ATOMNAME = atom_name_ok($line, $parameters[5]);
	$RESNAME = res_name_ok($line, $parameters[6]);

	# Verifica se o atomo passa na opcao de estrutura secundaria
	$SECONDSTR = 
		secondary_structure_ok(\$line, \@helix, \@sheet, \@turn, \$parameters[7]);

	#print $ATOMTYPE,$CHAIN,$OCCUP,$ATOMRANGE,$RESRANGE,$ATOMNAME,$RESNAME,$SECONDSTR."\n";

	# Se a linha passa em todos os quesitos ela e' aceita
	if(	$ATOMTYPE 	and $CHAIN		and $OCCUP 		and
		$ATOMRANGE 	and $RESRANGE 	and $ATOMNAME 	and 
		$RESNAME 	and $SECONDSTR ){
		return 1;
	}
	# Caso contrario ela e' rejeitada
	else{
		return 0;
	}
}
#----------------------------------------------------------------------------------------
# Subrotina relacionada ao parametro ATOMTYPE
sub atom_type_ok(@){

	my($line, $parameter) = @_;
	my($aux);
	# Quebra a linha entre as virgulas
	my(@aux2) = split(/,/, $parameter);
	
	if(length($line) < 6){
		return 0;
	}
	else{
		$aux  = substr($line, 0, 6)
	}

	foreach $option (@aux2){
		# Opcao negada nao implementada ja que temos duas opcoes - ATOM ou HETATM
		# Alem disso:
		# NOT-ATOM = HETATM e
		# NOT-HETATM = ATOM.
		# O que torna a escolha trivial
		# 
		# Aceita toda as linhas de ATOM e HETATM
		if(($option eq "ALL") and (($aux eq "ATOM  ") or($aux eq "HETATM"))){
			return 1;
		}
		# Necessario porque $aux tem tamanho 6 e $option pode ter tamanho 6 ou 4
		# ATOM ou HETATM
		elsif(($aux eq $option) or ($aux eq $option."  ")){
			return 1;
		}	
	}
	return 0;
}
#----------------------------------------------------------------------------------------
# Subrotina relacionada ao parametro CHAIN
sub chain_ok(@){

	my($line, $parameter) = @_;
	my($aux);
	# Quebra a linha entre as virgulas
	my(@aux2) = split(/,/, $parameter);
	my($temp);
	my($i, $i_2);	# Auxiliares na utilizacao de mais de um NOT em uma opcao
	my($counter) = 0;
	$i = 0;

	if(length($line) < 22){
		return 0;
	}
	else{
		$aux = substr($line, 21, 1);
	}

	foreach $option (@aux2){
		# Opcao negada
		if(substr($option,0,4) eq "NOT-"){
			$counter++;
			if($counter == 1){
				$i = 1;
			}
			$temp = substr($option,4,length($option)-1);
			{if($aux ne $temp){
				$i_2 = 1;
			}
			else{
				$i_2 = 0;
			}}
			$i *= $i_2;
		}
		else{
			if($option eq "ALL"){
				return 1;
			}
			# Aceita somente atomos da cadeia
			elsif($aux eq $option){
				return 1;
			}
		}
	}
	if($i){
		return 1;
	}
	else{
		return 0;
	}
}
#----------------------------------------------------------------------------------------
# Subrotina relacionada ao parametro OCCUP
sub occupancy_ok(@){
	
	my($line, $parameter) = @_;
	my($aux);
	# Quebra a linha entre as virgulas
	my(@aux2) = split(/,/, $parameter);
	my($i, $i_2);	# Auxiliares na utilizacao de mais de um NOT em uma opcao
	my($counter) = 0;
	$i = 0;

	if(length($line) < 17){
		return 0;
	}
	else{
		$aux  = substr($line, 16, 1);
	}

	foreach $option (@aux2){
		# Opcao negada
		if(substr($option,0,4) eq "NOT-"){
			$counter++;
			if($counter == 1){
				$i = 1;
			}
			$temp = substr($option,4,length($option)-1);
			{if($aux ne $temp){
				$i_2 = 1;
			}
			else{
				$i_2 = 0;
			}}
			$i *= $i_2;
		}
		else{
			# Mais frequente
			if($option eq "+" and ((substr($line,0,4) eq "ATOM") or (substr($line,0,6) eq "HETATM"))
				and (trim(substr($line,56,4)) >= 0.50) and (trim(substr($line,56,4)) != 1.00)){
				return 1;
			}
			# Menos frequente
			elsif($option eq "-" and ((substr($line,0,4) eq "ATOM") or (substr($line,0,6) eq "HETATM"))
				and (trim(substr($line,56,4)) < 0.50)){
				return 1;
			}
			elsif($option eq "ALL"){
				return 1;
			}
			# Aceita os atomos segundo o parametro passado 
			elsif($aux eq $option){
				return 1;
			}
		}
	}
	if($i){
		return 1;
	}
	else{
		return 0;
	}
}
#----------------------------------------------------------------------------------------
# Subrotina relacionada ao parametro ATOMRANGE
sub atom_range_ok(@){

	my($line, $parameter) = @_;
	my($aux);
	my($temp);
	my($i, $i_2);	# Auxiliares na utilizacao de mais de um NOT em uma opcao
	my($counter) = 0;
	$i = 0;

	if(length($line) < 11){
		return 0;
	}
	else{
		$aux   = substr($line, 7, 4);
	}

	my($temp2) = trim($aux);
	# Quebra a linha entre as virgulas
	my(@aux2) = split(/,/, $parameter);
	foreach $option (@aux2){
		# Formato do intervalo: ,x-y,p-q,
		# Opcao negada
		if(substr($option,0,4) eq "NOT-"){
			$counter++;
			if($counter == 1){
				$i = 1;
			}
			$temp = substr($option,4,length($option)-1);
			if(($temp ne "ATOMRANGE = ") and ($temp ne "\n") and is_numeric($temp2)){
				@aux3 = split(/-/, $temp);
				# Se faz parte do intervalo considerado
				if(!(($temp2 >= $aux3[0]) and ($temp2 <= $aux3[1]))){
					$i_2 = 1;
				}
				else{
					$i_2 = 0;
				}
				$i *= $i_2;
			}
		}
		else{
			if(($option ne "ATOMRANGE = ") and ($option ne "\n") and is_numeric($temp2)){
				@aux3 = split(/-/, $option);
				if($option eq "ALL"){
					return 1;
				}
				# Se faz parte do intervalo considerado
				elsif(($temp2 >= $aux3[0]) and ($temp2 <= $aux3[1])){
					return 1;
				}	
			}
		}
	}
	if($i){
		return 1;
	}
	else{
		return 0;
	}
}
#----------------------------------------------------------------------------------------
# Subrotina relacionada ao parametro RESRANGE
sub res_range_ok(@){

	my($line, $parameter) = @_;
	my($aux);
	my($temp);
	my($i, $i_2);	# Auxiliares na utilizacao de mais de um NOT em uma opcao
	my($counter) = 0;
	$i = 0;

	if(length($line) < 27){
		return 0;
	}
	else{
		$aux = trim(substr($line,22,5));
	}
	my($temp2) = trim($aux);
	# Quebra a linha entre as virgulas
	my(@aux2) = split(/,/, $parameter);
	foreach $option (@aux2){
		# Formato do intervalo: ,x-y,p-q,
		# Opcao negada
		if(substr($option,0,4) eq "NOT-"){
			$counter++;
			if($counter == 1){
				$i = 1;
			}
			$temp = substr($option,4,length($option)-1);
			if(($temp ne "RESRANGE = ") and ($temp ne "\n") and is_numeric($temp2)){
				@aux3 = split(/-/, $temp);
				# Se faz parte do intervalo considerado
				if(!(($temp2 >= $aux3[0]) and ($temp2 <= $aux3[1]))){
					$i_2 = 1;
				}
				else{
					$i_2 = 0;
				}
				$i *= $i_2;
			}	
		}
		else{
			if(($option ne "RESRANGE = ") and ($option ne "\n") and is_numeric($temp2)){
				@aux3 = split(/-/, $option);
				if($option eq "ALL"){
					return 1;
				}
				# Se faz parte do intervalo considerado
				elsif(($temp2 >= $aux3[0]) and ($temp2 <= $aux3[1])){
					return 1;
				}	
			}
		}
	}
	if($i){
		return 1;
	}
	else{
		return 0;
	}
}
#----------------------------------------------------------------------------------------
# Subrotina relacionada ao parametro ATOMNAME
sub atom_name_ok(@){

	my($line, $parameter) = @_;
	my($aux);
	# Quebra a linha entre as virgulas
	my(@aux2) = split(/,/, $parameter);
	my(@aux3);
	my($temp);
	my($i, $i_2);	# Auxiliares na utilizacao de mais de um NOT em uma opcao
	my($counter) = 0;
	my($option);
	$i = 0;

	if(length($line) < 16){
		return 0;
	}
	else{
		$aux = substr($line, 13, 3);
	}

	foreach $option (@aux2){
		# Opcao negada
		if(substr($option,0,4) eq "NOT-"){
			$counter++;
			if($counter == 1){
				$i = 1;
			}
			$temp = substr($option,4,length($option)-1);
			{
			# MACRO generica para ATOMNAME - Seleciona um certo atomo de um certo residuo
			# atomName-resName
			@aux3 = split(/-/, $temp);
			if((substr($option,0,8) ne "ATOMNAME") and ((substr($option,0,1) ne "\n")) and 
				@aux3 and (trim(substr($line,12,4)) eq $aux3[0]) and 
				(trim(substr($line,17,3)) eq $aux3[1])){
				$i_2 = 0;
			}
			# MACRO para ATOMNAME - Seleciona atomos do grupo HEM
			elsif(($temp eq "HEM") and (res_name_ok($line, "HEM")) and
				(  ($aux eq "FE ") or ($aux eq "CHA") or ($aux eq "CHB")
				or ($aux eq "CHC") or ($aux eq "CHD") or ($aux eq "N A")
				or ($aux eq "C1A") or ($aux eq "C2A") or ($aux eq "C3A")
				or ($aux eq "C4A") or ($aux eq "CMA") or ($aux eq "CAA")
				or ($aux eq "CBA") or ($aux eq "CGA") or ($aux eq "O1A")
				or ($aux eq "O2A") or ($aux eq "N B") or ($aux eq "C1B")
				or ($aux eq "C2B") or ($aux eq "C3B") or ($aux eq "C4B")
				or ($aux eq "CMB") or ($aux eq "CAB") or ($aux eq "CBB")
				or ($aux eq "N C") or ($aux eq "C1C") or ($aux eq "C2C")
				or ($aux eq "C3C") or ($aux eq "C4C") or ($aux eq "CMC")
				or ($aux eq "CAC") or ($aux eq "CBC") or ($aux eq "N D")
				or ($aux eq "C1D") or ($aux eq "C2D") or ($aux eq "C3D")
				or ($aux eq "C4D") or ($aux eq "CMD") or ($aux eq "CAD")
				or ($aux eq "CBD") or ($aux eq "CGD") or ($aux eq "O1D")
				or ($aux eq "O2D"))){
				$i_2 = 0;
			}
			# MACRO para ATOMNAME - Seleciona atomos do grupo CMO
			elsif(($temp eq "CMO") and (res_name_ok($line, "CMO")) 
				and (($aux eq "O  ") or ($aux eq "C  "))){
				$i_2 = 0;
			}
			# MACRO para ATOMNAME - Seleciona atomos do backbone
			elsif(($temp eq "BACKBONE") and (atom_type_ok($line, "ATOM  ")) and 
				(($aux eq "N  ") or ($aux eq "O  ") or ($aux eq "C  ") or 
				($aux eq "CA "))){
				$i_2 = 0;
			}
			# MACRO para ATOMNAME - Seleciona atomos de hidrogenios
			elsif(($temp eq "H*") and (substr(trim(substr($line,12,2)),0,1) eq "H" or
				(length(trim(substr($line,12,2)))==2 and
				(substr(trim(substr($line,12,2)),1,1) eq "H")))){
				$i_2 = 0;
			}
			elsif(($aux ne $temp) and ($aux ne $temp." ") and ($aux ne $temp."  ") and 
				(trim($aux) ne trim($temp))){
				$i_2 = 1;
			}
			else{
				$i_2 = 0;
			}}
			$i *= $i_2;
		}
		else{
			@aux3 = split(/-/, $option);
			if($option eq "ALL"){
				return 1;
			}
			# Necessario porque nome do atomo tem tamanho variavel 
			# (pode haver caracteres brancos em $aux)
			elsif(($aux eq $option) or ($aux eq $option." ") or ($aux eq $option."  ")){
				return 1;
			}
			# MACRO para ATOMNAME - Seleciona o carbono alfa de todas glicinas
			elsif((substr($option,0,8) ne "ATOMNAME") and ((substr($option,0,1) ne "\n")) and 
				@aux3 and (trim(substr($line,12,4)) eq $aux3[0]) and 
				(trim(substr($line,17,3)) eq $aux3[1])){
				return 1;
			}
			# MACRO para ATOMNAME - Seleciona atomos do grupo HEM
			elsif(($option eq "HEM") and (res_name_ok($line, "HEM")) and
				(  ($aux eq "FE ") or ($aux eq "CHA") or ($aux eq "CHB")
				or ($aux eq "CHC") or ($aux eq "CHD") or ($aux eq "N A")
				or ($aux eq "C1A") or ($aux eq "C2A") or ($aux eq "C3A")
				or ($aux eq "C4A") or ($aux eq "CMA") or ($aux eq "CAA")
				or ($aux eq "CBA") or ($aux eq "CGA") or ($aux eq "O1A")
				or ($aux eq "O2A") or ($aux eq "N B") or ($aux eq "C1B")
				or ($aux eq "C2B") or ($aux eq "C3B") or ($aux eq "C4B")
				or ($aux eq "CMB") or ($aux eq "CAB") or ($aux eq "CBB")
				or ($aux eq "N C") or ($aux eq "C1C") or ($aux eq "C2C")
				or ($aux eq "C3C") or ($aux eq "C4C") or ($aux eq "CMC")
				or ($aux eq "CAC") or ($aux eq "CBC") or ($aux eq "N D")
				or ($aux eq "C1D") or ($aux eq "C2D") or ($aux eq "C3D")
				or ($aux eq "C4D") or ($aux eq "CMD") or ($aux eq "CAD")
				or ($aux eq "CBD") or ($aux eq "CGD") or ($aux eq "O1D")
				or ($aux eq "O2D"))){
				return 1;
			}
			# MACRO para ATOMNAME - Seleciona atomos do grupo CMO
			elsif(($option eq "CMO") and (res_name_ok($line, "CMO")) 
				and (($aux eq "O  ") or ($aux eq "C  "))){
				return 1;
			}
			# MACRO para ATOMNAME - Seleciona atomos do backbone
			elsif(($option eq "BACKBONE") and (atom_type_ok($line, "ATOM")) and 
				(($aux eq "N  ") or ($aux eq "O  ") or ($aux eq "C  ") or ($aux eq "CA "))){
				return 1;
			}
			# MACRO para ATOMNAME - Seleciona atomos de hidrogenios
			elsif(($option eq "H*") and (substr(trim(substr($line,12,2)),0,1) eq "H" or
				(length(trim(substr($line,12,2)))==2 and
				(substr(trim(substr($line,12,2)),1,1) eq "H")))){
				return 1;
			}
		}
	}
	if($i){
		return 1;
	}
	else{
		return 0;
	}
}
#----------------------------------------------------------------------------------------
# Subrotina relacionada ao parametro RESNAME
sub res_name_ok(@){

	my($line, $parameter) = @_;
	my($aux);

	# Quebra a linha entre as virgulas
	my(@aux2) = split(/,/, $parameter);
	my($temp);
	my($i, $i_2);	# Auxiliares na utilizacao de mais de um NOT em uma opcao
	my($counter) = 0;
	$i = 0;

	if(length($line) < 20){
		return 0;
	}
	else{
		$aux = substr($line, 17, 3);
	}

	foreach $option (@aux2){
		# Opcao negada
		if(substr($option,0,4) eq "NOT-"){
			$counter++;
			if($counter == 1){
				$i = 1;
			}
			$temp = substr($option,4,length($option)-1);
			{# MACRO - CHAIN = todos os 20 aminoacidos
			if($temp eq "CHAIN" and (($aux eq "ALA") or ($aux eq "VAL") or ($aux eq "LEU") or 
				($aux eq "GLY") or ($aux eq "SER") or ($aux eq "TRP") or ($aux eq "THR") or 
				($aux eq "GLN") or ($aux eq "GLU") or ($aux eq "CYS") or ($aux eq "ARG") or 
				($aux eq "PRO") or ($aux eq "ASP") or ($aux eq "PHE") or ($aux eq "ILE") or 
				($aux eq "HIS") or ($aux eq "ASN") or ($aux eq "MET") or ($aux eq "TYR") or 
				($aux eq "LYS") or ($aux eq "MSE"))){
				$i_2 = 0;
			}
			elsif($aux ne $temp){
				$i_2 = 1;
			}
			else{
				$i_2 = 0;
			}}
			$i *= $i_2;
		}
		else{
			# MACRO - CHAIN = todos os 20 aminoacidos
			if($option eq "CHAIN" and (($aux eq "ALA") or ($aux eq "VAL") or ($aux eq "LEU") or 
				($aux eq "GLY") or ($aux eq "SER") or ($aux eq "TRP") or ($aux eq "THR") or 
				($aux eq "GLN") or ($aux eq "GLU") or ($aux eq "CYS") or ($aux eq "ARG") or 
				($aux eq "PRO") or ($aux eq "ASP") or ($aux eq "PHE") or ($aux eq "ILE") or 
				($aux eq "HIS") or ($aux eq "ASN") or ($aux eq "MET") or ($aux eq "TYR") or 
				($aux eq "LYS") or ($aux eq "MSE"))){
				return 1;
			}
			# MACRO - Seleciona grupo HEM
			elsif(($option eq "HEM") and
				(  atom_name_ok($line, "FE ") or atom_name_ok($line, "CHA")
				or atom_name_ok($line, "CHB") or atom_name_ok($line, "CHC")
				or atom_name_ok($line, "CHD") or atom_name_ok($line, "N A")
				or atom_name_ok($line, "C1A") or atom_name_ok($line, "C2A")
				or atom_name_ok($line, "C3A") or atom_name_ok($line, "C4A")
				or atom_name_ok($line, "CMA") or atom_name_ok($line, "CAA")
				or atom_name_ok($line, "CBA") or atom_name_ok($line, "CGA")
				or atom_name_ok($line, "O1A") or atom_name_ok($line, "O2A")
				or atom_name_ok($line, "N B") or atom_name_ok($line, "C1B")
				or atom_name_ok($line, "C2B") or atom_name_ok($line, "C3B")
				or atom_name_ok($line, "C4B") or atom_name_ok($line, "CMB")
				or atom_name_ok($line, "CAB") or atom_name_ok($line, "CBB")
				or atom_name_ok($line, "N C") or atom_name_ok($line, "C1C")
				or atom_name_ok($line, "C2C") or atom_name_ok($line, "C3C")
				or atom_name_ok($line, "C4C") or atom_name_ok($line, "CMC")
				or atom_name_ok($line, "CAC") or atom_name_ok($line, "CBC")
				or atom_name_ok($line, "N D") or atom_name_ok($line, "C1D")
				or atom_name_ok($line, "C2D") or atom_name_ok($line, "C3D")
				or atom_name_ok($line, "C4D") or atom_name_ok($line, "CMD")
				or atom_name_ok($line, "CAD") or atom_name_ok($line, "CBD")
				or atom_name_ok($line, "CGD") or atom_name_ok($line, "O1D")
				or atom_name_ok($line, "O2D"))){
				return 1;
			}
			elsif($option eq "ALL"){
				return 1;
			}
			# Necessario porque nome do atomo tem tamanho variavel 
			# (pode haver caracteres brancos em $aux)
			elsif($aux eq $option){
				return 1;
			}
		}
	}
	if($i){
		return 1;
	}
	else{
		return 0;
	}
}
#----------------------------------------------------------------------------------------
# Subrotina relacionada ao parametro SECONDSTRUCT
sub secondary_structure_ok(\@$){
	
	my($line) = ${$_[0]};			# Linha a ser avaliada
	my(@helix) = @{$_[1]};			# Conjunto de atomos pertencentes a alfa helices
	my(@sheet) = @{$_[2]};			# Conjunto de atomos pertencentes a folhas beta
	my(@turn) = @{$_[3]};			# Conjunto de atomos pertencentes a voltas ou loops
	my($parameter) = ${$_[4]};		# Linha com o valor da opcao

	my($temp);
	my($temp_x);
	my($temp_i, $temp_f);
	my($index) = 0;
	my($i) = 0;
	my($i_1, $i_2);	# Auxiliares na utilizacao de mais de um NOT em uma opcao
	my($counter) = 0;
	$i_1 = 0;

	# Quebra a linha entre as virgulas
	my(@aux2) = split(/,/, $parameter);
	foreach $option (@aux2){
		# Opcao negada - Chama-se resrange com "NOT"
		if(substr($option,0,4) eq "NOT-"){
			$counter++;
			if($counter == 1){
				$i_1 = 1;
				$i = 0;
			}
			$temp_x = substr($option,4,length($option)-1);
			{ if($temp_x eq "HELIX"){
				for(@helix){
					# Caso a proteina nao possua helices
					if(scalar(@helix) == 0){$i_2 = 1;}
	
					$temp_i = trim($helix[$i][0]);
					$temp_f = trim($helix[$i][1]);
					$temp = "RESRANGE = ,NOT-".$temp_i."-".$temp_f.",";

					if(res_range_ok($line, $temp)){
						$i_2 = 1;
					}
					else{
						$i_2 = 0;
					}
					$i_1 *= $i_2;
					$i++;
				}
			}
			elsif(substr($temp_x,0,length($temp_x)-1) eq "HELIX"){
				$index = substr($temp_x,length($temp_x)-1,1)-1;
				# Caso a proteina nao possua helices
				if(scalar(@helix) == 0){$i_2 = 1;}

				$temp_i = trim($helix[$index][0]);
				$temp_f = trim($helix[$index][1]);
				$temp = "RESRANGE = ,NOT-".$temp_i."-".$temp_f.",";

				if(res_range_ok($line, $temp)){
					$i_2 = 1;
				}
				else{
					$i_2 = 0;
				}
				$i_1 *= $i_2;
				$i++;
			}
			elsif($temp_x eq "SHEET"){
				for(@sheet){
					# Caso a proteina nao possua folhas beta
					if(scalar(@sheet) == 0){$i_2 = 1;}

					$temp_i = trim($sheet[$i][0]);
					$temp_f = trim($sheet[$i][1]);

					$temp = "RESRANGE = ,NOT-".$temp_i."-".$temp_f.",";

					if(res_range_ok($line, $temp)){
						$i_2 = 1;
					}
					else{
						$i_2 = 0;
					}
					$i_1 *= $i_2;
					$i++;
				}
			}
			elsif(substr($temp_x,0,length($temp_x)-1) eq "SHEET"){
				$index = substr($temp_x,length($temp_x)-1,1);
				for(@sheet){
					# Caso a proteina nao possua helices
					if(scalar(@sheet) == 0){$i_2 = 1;}

					$temp_i = trim($sheet[$i][0]);
					$temp_f = trim($sheet[$i][1]);
					$temp = "RESRANGE = ,NOT-".$temp_i."-".$temp_f.",";
	
					if(($index == $sheet[$i][2]) and (res_range_ok($line, $temp))){
						$i_2 = 1;
					}
					else{
						$i_2 = 0;
					}
					$i_1 *= $i_2;
					$i++;
				}
			}
			elsif($temp_x eq "TURN"){
				for(@turn){
					# Caso a proteina nao possua loops
					if(scalar(@turn) == 0){$i_2 = 1;}
		
					$temp_i = trim($turn[$i][0]);
					$temp_f = trim($turn[$i][1]);
					$temp = "RESRANGE = ,NOT-".$temp_i."-".$temp_f.",";

					if(res_range_ok($line, $temp)){
						$i_2 = 1;
					}
					else{
						$i_2 = 0;
					}
					$i_1 *= $i_2;
					$i++;
				}
			}
			elsif(substr($temp_x,0,length($temp_x)-1) eq "TURN"){
				$index = substr($temp_x,length($temp_x)-1,1)-1;
				# Caso a proteina nao possua loops
				if(scalar(@turn) == 0){$i_2 = 1;}
				
				$temp_i = trim($turn[$index][0]);
				$temp_f = trim($turn[$index][1]);
				$temp = "RESRANGE = ,NOT-".$temp_i."-".$temp_f.",";

				if(res_range_ok($line, $temp)){
					$i_2 = 1;
				}
				else{
					$i_2 = 0;
				}
				$i_1 *= $i_2;
				$i++;
			} }
		}
		else{
			if($option eq "ALL"){
				return 1;
			}
			elsif($option eq "HELIX"){
				$i = 0;
				for(@helix){
					# Caso a proteina possua helices
					if(scalar(@helix) != 0){
						$temp_i = trim($helix[$i][0]);
						$temp_f = trim($helix[$i][1]);
						$temp = "RESRANGE = ,".$temp_i."-".$temp_f.",";
						if(res_range_ok($line, $temp)){
							return 1;
						}
						$i++;
					}
				}
			}
			elsif(substr($option,0,length($option)-1) eq "HELIX"){
				$i = 0;
				$index = substr($option,length($option)-1,1)-1;
				# Caso a proteina tenha helices
				if(scalar(@helix) != 0){
					$temp_i = trim($helix[$index][0]);
					$temp_f = trim($helix[$index][1]);
	
					$temp = "RESRANGE = ,".$temp_i."-".$temp_f.",";
					if(res_range_ok($line, $temp)){
						return 1;
					}
					$i++;
				}
			}
			elsif($option eq "SHEET"){
				$i = 0;
				for(@sheet){
					# Se a proteina possuir folhas beta
					if(scalar(@sheet) != 0){
						$temp_i = trim($sheet[$i][0]);
						$temp_f = trim($sheet[$i][1]);
						$temp = "RESRANGE = ,".$temp_i."-".$temp_f.",";
						if(res_range_ok($line, $temp)){
							return 1;
						}
						$i++;
					}
				}
			}
			elsif(substr($option,0,length($option)-1) eq "SHEET"){
				$i = 0;
				$index = substr($option,length($option)-1,1);
				for(@sheet){
					# Se a proteina possuir folhas beta
					if(scalar(@sheet) != 0){
						$temp_i = trim($sheet[$i][0]);
						$temp_f = trim($sheet[$i][1]);
						$temp = "RESRANGE = ,".$temp_i."-".$temp_f.",";
						if(($index == $sheet[$i][2]) and (res_range_ok($line, $temp))){
							return 1;
						}
						$i++;
					}
				}
			}
			elsif($option eq "TURN"){
				$i = 0;
				for(@turn){
					# Se a proteina possuir loops
					if(scalar(@turn) != 0){
						$temp_i = trim($turn[$i][0]);
						$temp_f = trim($turn[$i][1]);
						$temp = "RESRANGE = ,".$temp_i."-".$temp_f.",";
						if(res_range_ok($line, $temp)){
							return 1;
						}
						$i++;
					}
				}
			}
			elsif(substr($option,0,length($option)-1) eq "TURN"){
				$i = 0;
				$index = substr($option,length($option)-1,1)-1;
				# Se a proteina possuir loops
				if(scalar(@turn) != 0){
					$temp_i = trim($turn[$index][0]);
					$temp_f = trim($turn[$index][1]);
					$temp = "RESRANGE = ,".$temp_i."-".$temp_f.",";
					if(res_range_ok($line, $temp)){
						return 1;
					}
					$i++;
				}
			}
		}
	}
	if($i_1){
		return 1;
	}
	else{
		return 0;
	}
}
#----------------------------------------------------------------------------------------
return 1
