#!/usr/bin/perl -w

use File::Basename; # Added by Alexandre Fassio 

# *******************************************************
# *		Grupo de Bioinformatica Estrutural				*
# *		UFMG/DCC										*
# *   ----------------------------------------------	*
# *														*
# * Douglas Eduardo Valente Pires - dpires@dcc.ufmg.br	*
# * www.dcc.ufmg.br/~dpires								*
# * Ultima Modificacao :: 11/01/2009					*
# *   ----------------------------------------------	*
# * "With great power, comes great responsibility."		*
# *******************************************************

# Programa ordena contatos calculados eliminando repeticoes.

sub trim;

$inFile = $ARGV[0];		# Arquivo de entrada

#------------------------------------------------------------------------------------#
if(scalar(@ARGV) < 1){
	print "#####################################################################\n";
	print " SINTAXE:\n\tperl ordena_contatos.pl <in_arqs>\n";
	print " Script ordena contatos calculados eliminando repeticoes.\n";
	print "#####################################################################\n";
	exit;
}
#------------------------------------------------------------------------------------#

# Cria fluxo ligado ao arquivo de entrada (leitura)
open(INFILE,"<$inFile") or die "$!Erro ao abrir: $inFile\n";
@files = <INFILE>;		# Armazena o arquivo em um arranjo
close INFILE;			# Fecha fluxo ligado ao arquivo

#------------------------------------------------------------------------------------#
# Extrai informacoes sobre as posicoes dos atomos
foreach $arq (@files){

	chomp($arq);

	# Cria fluxo ligado ao arquivo de entrada (leitura)
	open(INFILE,"<$arq") or die "$!Erro ao abrir: $arq\n";
	@info = <INFILE>;		# Armazena o arquivo em um arranjo
	close INFILE;			# Fecha fluxo ligado ao arquivo

	$counter = 0;
	foreach $line (@info){
		chomp($line);

		@aux = split(" ", $line);

		if($aux[0] <= $aux[1]){
			$out[$counter] = $line."\n";
		}
		else{
			$out[$counter] = sprintf '%d%s%d%s',$aux[1]," ",$aux[0],"\n";
		}
		$counter++;
	}

	open(OUTFILE,">$arq.tmp") or die "$!Erro ao abrir: $arq.tmp\n";
	for($i=0; $i<$counter; $i++){
		print OUTFILE $out[$i];
	}
	close OUTFILE;

	# Ordena numericamente eliminando repeticoes se existirem
#	my ($pdb_entry,$path) = fileparse($arq,qr/(\.[^.]*)*/); # Added by Alexandre Fassio 
	my ($pdb_entry,$path) = fileparse($arq,qr/.DT/); # Added by Alexandre Fassio 
	my $output = $path . $pdb_entry . ".DT.sorted"; # Added by Alexandre Fassio 
	`sort -n -k1 -k2 -u -o $output $arq.tmp`;
	`rm $arq.tmp`;

	print "$arq\n";
}
#------------------------------------------------------------------------------------#
# Fim do programa
exit;

# Elimina caracteres brancos nas extremidade de uma string
sub trim($){
	my $string = shift;
	$string =~ s/^\s+//;
	$string =~ s/\s+$//;
	return $string;
}
