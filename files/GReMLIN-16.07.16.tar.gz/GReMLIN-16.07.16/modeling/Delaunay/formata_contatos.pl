#!/usr/bin/perl -w

# *******************************************************
# *		Grupo de Bioinformatica Estrutural				*
# *		UFMG/DCC										*
# *   ----------------------------------------------	*
# *														*
# * Douglas Eduardo Valente Pires - dpires@dcc.ufmg.br	*
# * www.dcc.ufmg.br/~dpires								*
# * Ultima Modificacao :: 22/10/2008					*
# *   ----------------------------------------------	*
# * "With great power, comes great responsibility."		*
# *******************************************************

# Programa formata saidas geradas para Delaunay e AlphaShape.

sub trim;

$inFile = $ARGV[0];		# Arquivo de entrada

#------------------------------------------------------------------------------------#
if(scalar(@ARGV) < 1){
	print "#####################################################################\n";
	print " SINTAXE:\n\tperl formata_contatos.pl <in_arqs>\n";
	print " Script formata saidas geradas via DT.\n";
	print "#####################################################################\n";
	exit;
}
#------------------------------------------------------------------------------------#

# Cria fluxo ligado ao arquivo de entrada (leitura)
open(INFILE,"<$inFile") or die "$!Erro ao abrir: $inFile\n";
@files = <INFILE>;		# Armazena o arquivo em um arranjo
close INFILE;			# Fecha fluxo ligado ao arquivo

# Conteudo de files:
# 	<arq1.coord.dt>
# 	. . .
# 	<arqn.coord.dt>

#------------------------------------------------------------------------------------#
# Extrai informacoes sobre as posicoes dos atomos
for($k=0; $k<scalar(@files); $k++){

	chomp($files[$k]);		$dtFile = $files[$k];

	# Cria fluxo ligado ao arquivo dt (leitura)
	open(DT,"<$dtFile") or die "$!Erro ao abrir: $dtFile\n";
	@dt = <DT>;		# Armazena o arquivo em um arranjo
	close DT;			# Fecha fluxo ligado ao arquivo

	# Imprime arquivos de saida
	$outFileDT = $dtFile.".formatted";

	# Cria fluxo ligado aos arquivos de saida (escrita)
	open(OUTFILE_DT,">$outFileDT") or die "$!Erro ao abrir: $outFileDT\n";

#------------------------------------------------------------------------------------#
	# Extrai contatos gerados pelo Delaunay Tesselation
	foreach $info_dt (@dt){
		@aux = split(",",$info_dt);

		@aux1 = split(" ",$aux[0]);
		@aux2 = split(" ",$aux[1]);
		@aux3= split(" ",$aux[2]);
		@aux4= split(" ",$aux[3]);

		printf OUTFILE_DT '%.3f %.3f %.3f,%.3f %.3f %.3f,%.3f %.3f %.3f,%.3f %.3f %.3f,%d,%d'."\n",
			$aux1[0],$aux1[1],$aux1[2], $aux2[0],$aux2[1],$aux2[2], $aux3[0],$aux3[1],$aux3[2],
			$aux4[0],$aux4[1],$aux4[2], $aux[4],$aux[5];
	}
	close OUTFILE_DT;
}
#------------------------------------------------------------------------------------#
# Fim do programa
exit;

# Elimina caracteres brancos nas extremidade de uma string
sub trim($){
	my $string = shift;
	$string =~ s/^\s+//;
	$string =~ s/\s+$//;
	return $string;
}