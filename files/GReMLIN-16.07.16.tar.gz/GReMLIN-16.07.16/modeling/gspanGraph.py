#-----------------------------------------------------------------------
# Structural Bioinformatics Group DPI-Universidade Federal de Vicosa
# Developed by Sabrina Azevedo
# 05/05/2016
#-----------------------------------------------------------------------

import getopt
import sys
import re
import numpy as np
from scipy.sparse import csgraph
import os
import constants

def createAtomOrInteractionTypeMap(atomType):
    atomOrInteractionTypeMapping = {}
    with open(atomType) as fp:
        for line in fp:
            line = line.strip('\n')
            vectorTemp = line.split(constants.sepPv)
            type = vectorTemp[0] # string atom or interaction type
            value = vectorTemp[1] # prime number representing atom or interaction type
            atomOrInteractionTypeMapping[type] = value
    fp.close()
    return atomOrInteractionTypeMapping

# 3QQF.A.DT.sorted.ctc
def createGspanGraphAndMappingsForListOfCtcFiles(listOfcontactFile, outFileGspan, atomTypeMapping, interactionTypeMapping, outdir):
    graphIndex = 0
    fout = open(outFileGspan, 'w')
    with open(listOfcontactFile) as fp:
        for line in fp:

            ctcFile = line.strip('\n')
            searchObjPDBidChain = re.search( r'^(.+)([\w]{4}\.\w)\.DT\.sorted\.ctc$', ctcFile)

            if searchObjPDBidChain: # test if the line is a regular ctc filename
                if os.path.isfile(ctcFile): # test if the ctc file exists
                    pdbidChain = searchObjPDBidChain.group(2);
                    mapPdbAtomIndexToSequentialIndex, mapPdbAtomIndexToAtomType, mapEdgeToEdgeType, mapStringEdgeTypeToEnglishEdgeType,\
                    mapPdbNodeIndexToItsInfo, mapStringEdgeTypeToDistance =\
                            createAtomAndEdgeMappingsFromCtcFile(ctcFile, pdbidChain, graphIndex, atomTypeMapping, interactionTypeMapping)

                    if mapPdbAtomIndexToSequentialIndex: # this dict is filled if and only if there are at least one no null interactions

                        pdbIdChainGraphAsAdjacencyMatrix = createGraphAdjacencyMatrix(mapPdbAtomIndexToSequentialIndex, mapEdgeToEdgeType)
                        stringGraphsForConnectedComponent, graphStartIndexInGspan = createGspanGraph(pdbIdChainGraphAsAdjacencyMatrix,
                                mapPdbAtomIndexToSequentialIndex, mapPdbAtomIndexToAtomType, mapEdgeToEdgeType, graphIndex, pdbidChain,
                                mapStringEdgeTypeToEnglishEdgeType, mapPdbNodeIndexToItsInfo, mapStringEdgeTypeToDistance, outdir)
                        graphIndex = graphStartIndexInGspan
                        fout.write(stringGraphsForConnectedComponent)
                    else:
                        print("\nArquivo não possui interações entre proteína-ligante: ", ctcFile)
                else:
                    print("\nArquivo não existe: ", ctcFile)
            else:
                print("Nao encontrou pdbid chain no nome do arquivo: ", ctcFile)
    fp.close()
    fout.close()

def createAtomAndEdgeMappingsFromCtcFile(ctcFile, pdbidChain, graphIndex, atomTypeMapping, interactionTypeMapping):
    contLine = 0
    contNode = 0
    mapPdbAtomIndexToSequentialIndex = {}
    mapPdbAtomIndexToAtomType = {}
    mapEdgeToEdgeType = {}
    mapPdbNodeIndexToItsInfo = {}
    mapStringEdgeTypeToEnglishEdgeType = {}

    # sabrina alterou em 08/06/2016
    mapStringEdgeTypeToDistance ={}

    with open(ctcFile) as fp:
            for line in fp:
                #contLine = contLine + 1
                if contLine != 0: # descarta 1a linha pois eh cabecalho
                    line = line.strip('\n')
                    tempVec = line.split(constants.sepPv)
                    if tempVec[11] != "null": # considera apenas as arestas que representam interacao (de acordo com tipo dos nós e criterio de distancia)
                        sourceAtomIndex = tempVec[0]
                        targetAtomIndex = tempVec[5]
                        sourceType = changeStringNodeTypeToIntNodeType(tempVec[4], atomTypeMapping)
                        targetType =  changeStringNodeTypeToIntNodeType(tempVec[9], atomTypeMapping)
                        edgeType = changeStringEdgeTypeToIntEdgeType(tempVec[11], interactionTypeMapping)
                        edgeTypeEnglish = changeStringEdgeTypeToEnglishEdgeType(tempVec[11])

                        # sabrina alterou em 08/06/2016
                        distance = tempVec[10]

                        if sourceAtomIndex not in mapPdbAtomIndexToSequentialIndex:
                            mapPdbAtomIndexToSequentialIndex[sourceAtomIndex] = contNode
                            contNode = contNode + 1

                        if targetAtomIndex not in mapPdbAtomIndexToSequentialIndex:
                            mapPdbAtomIndexToSequentialIndex[targetAtomIndex] = contNode
                            contNode = contNode + 1

                        if sourceAtomIndex not in mapPdbAtomIndexToAtomType:
                            mapPdbAtomIndexToAtomType[sourceAtomIndex] = sourceType

                        if targetAtomIndex not in mapPdbAtomIndexToAtomType:
                            mapPdbAtomIndexToAtomType[targetAtomIndex] = targetType

                        edge = str(sourceAtomIndex) + constants.underline + str(targetAtomIndex)
                        if edge not in mapEdgeToEdgeType:
                            mapEdgeToEdgeType[edge] = edgeType
                            mapStringEdgeTypeToEnglishEdgeType[edge] = edgeTypeEnglish


                        # sabrina alterou em 08/06/2016
                        if edge not in mapStringEdgeTypeToDistance:
                            mapStringEdgeTypeToDistance[edge] = distance


                        # TODO PREENCHER mapPdbNodeIndexToItsInfo
                        if sourceAtomIndex not in mapPdbNodeIndexToItsInfo:
                            # residue:residue_index:
                            info = tempVec[2] + constants.sepColon + tempVec[3] + constants.sepColon + tempVec[1]
                            mapPdbNodeIndexToItsInfo[sourceAtomIndex] = info

                        if targetAtomIndex not in mapPdbNodeIndexToItsInfo:
                            # residue:residue_index:atom_name
                            info = tempVec[7] + constants.sepColon + tempVec[8] + constants.sepColon + tempVec[6]
                            mapPdbNodeIndexToItsInfo[targetAtomIndex] = info

                contLine = contLine + 1
    fp.close()
    return mapPdbAtomIndexToSequentialIndex, mapPdbAtomIndexToAtomType, mapEdgeToEdgeType, mapStringEdgeTypeToEnglishEdgeType, mapPdbNodeIndexToItsInfo, mapStringEdgeTypeToDistance

# iterate over node types in string and convert to integer (a product of primes)
def changeStringNodeTypeToIntNodeType(stringNodeType, atomTypeMapping):
    tempVet = stringNodeType.split(constants.slash)
    nodeIntType = 1;
    #for i in range (1, len(tempVet)):
    for i in range(0, len(tempVet)):
        nodeTypeTemp = atomTypeMapping[tempVet[i]]
        nodeIntType = nodeIntType * int(nodeTypeTemp)
    return nodeIntType

def changeStringEdgeTypeToIntEdgeType(stringEdgeType, interactionTypeMapping):
    tempVet = stringEdgeType.split(constants.slash)
    edgeIntType = 1;
    for i in range (0, len(tempVet)):
        edgeTypeTemp = interactionTypeMapping[tempVet[i]]
        edgeIntType = edgeIntType * int(edgeTypeTemp)
    return edgeIntType

def createGraphAdjacencyMatrix(mapPdbAtomIndexToSequentialIndex, mapEdgeToEdgeType):
    nrows = len(mapPdbAtomIndexToSequentialIndex)
    ncols = len(mapPdbAtomIndexToSequentialIndex)
    graphAsAdjacencyMatrix = np.zeros((nrows, ncols))
    for edge in mapEdgeToEdgeType.keys(): # key = sourceAtomIndex_targetAtomIndex ; value = intEdgeType
        vetTemp = edge.split(constants.underline)
        atomIndex1 = vetTemp[constants.sourceAtomIndex]
        atomIndex2 = vetTemp[constants.targetAtomIndex]
        matrixIndex1 = mapPdbAtomIndexToSequentialIndex[atomIndex1]
        matrixIndex2 = mapPdbAtomIndexToSequentialIndex[atomIndex2]
        edgeType = mapEdgeToEdgeType[edge]
        graphAsAdjacencyMatrix[matrixIndex1, matrixIndex2] = edgeType # the matrix is symetric considering the main diagonal, which means, the interactios are repeated
        graphAsAdjacencyMatrix[matrixIndex2, matrixIndex1] = edgeType
    return graphAsAdjacencyMatrix

#TODO quem chama precisa ter o indice do grafo
def createGspanGraph(graphAsAdjacencyMatrix, mapPdbAtomIndexToSequentialIndex, mapPdbAtomIndexToAtomType, mapEdgeToEdgeType,
                     graphStartIndexInGspan, pdbIdChain, mapStringEdgeTypeToEnglishEdgeType, mapPdbNodeIndexToItsInfo, mapStringEdgeTypeToDistance, outdir):
    mapSequentialIndexToPdbAtomIndex = {}
    for pdbAtomIndex,  sequentialIndex in mapPdbAtomIndexToSequentialIndex.items(): # map sequential index to pdb atom index, which means, invert the original mapping
        mapSequentialIndexToPdbAtomIndex[sequentialIndex] = pdbAtomIndex
    n_components, component_list = csgraph.connected_components(graphAsAdjacencyMatrix, directed=False, return_labels=True) # component_list is a ndarray
    stringGraphsForConnectedComponent = ""

    for i in range (0, n_components): # iterate over the number of components (a graph)
        connectedComponent = np.where(component_list == i)[0] # get[0] because it is the vector with node indexes
        mapAdjacencyMatrixNodeIndexToGspanNodeIndex = {}
        cont = 0

        for j in range (0, len(connectedComponent)): # iterate over each node of a component and map adjacency matrix nodes to gspan nodes because each gspan graph starts from node 0
            adjacencyMatrixNodeIndex = connectedComponent[j]
            gspanNodeIndex = cont;
            if adjacencyMatrixNodeIndex not in mapAdjacencyMatrixNodeIndexToGspanNodeIndex:
                mapAdjacencyMatrixNodeIndexToGspanNodeIndex[adjacencyMatrixNodeIndex] = gspanNodeIndex
                cont = cont + 1

        gspanEdgeList = []
        for k in range (0, len(connectedComponent)): # iterate over each node of a component and generate the graph
            adjacencyMatrixNodeIndex = connectedComponent[k]
            pdbNodeIndex = mapSequentialIndexToPdbAtomIndex[adjacencyMatrixNodeIndex]
            gspanNodeIndex = mapAdjacencyMatrixNodeIndexToGspanNodeIndex[adjacencyMatrixNodeIndex]

            for l in range (0, len(graphAsAdjacencyMatrix)): # iterate over row of adjac matrix corresponding to a specific node of a connected component
                if(graphAsAdjacencyMatrix[adjacencyMatrixNodeIndex][l] != 0): # 0 positions do not represent interactions
                    targetAdjacMatrixNodeIndex = l
                    targetPdbNodeIndex = mapSequentialIndexToPdbAtomIndex[targetAdjacMatrixNodeIndex]
                    targetGspanNodeIndex = mapAdjacencyMatrixNodeIndexToGspanNodeIndex[targetAdjacMatrixNodeIndex]

                    # map edge to Pdb index and find edge type
                    pdbedge = ""
                    edgeType = 0
                    if int(pdbNodeIndex) < int(targetPdbNodeIndex):
                        pdbedge = pdbNodeIndex + constants.underline + targetPdbNodeIndex
                    else:
                        pdbedge = targetPdbNodeIndex + constants.underline + pdbNodeIndex
                    if pdbedge in mapEdgeToEdgeType:
                        edgeType = mapEdgeToEdgeType[pdbedge]
                    else:
                        print("Aresta não encontrada: ", pdbedge)
                        return None

                    # map node from adjacency matrix to gspan and put in the graph
                    gspanedge = ""

                    if int(gspanNodeIndex) < int(targetGspanNodeIndex):
                        gspanedge = str(gspanNodeIndex) + constants.underline+ str(targetGspanNodeIndex)
                    else:
                        gspanedge = str(targetGspanNodeIndex) + constants.underline + str(gspanNodeIndex)
                    # guardar as arestas do gspan sem repetir e mantendo a ordem
                    gspanEdgeAndType = gspanedge + constants.underline + str(edgeType)
                    if gspanEdgeAndType not in gspanEdgeList:
                        #gspanEdgeList.append(gspanedge + constants.underline + edgeType)
                        gspanEdgeList.append(gspanEdgeAndType)

        # TODO talvez seja interessante criar o grafo xml aqui e o .mpa também
        # mount gspan graph for one connected component
        graphString = mountGraph(connectedComponent, mapAdjacencyMatrixNodeIndexToGspanNodeIndex, gspanEdgeList, mapSequentialIndexToPdbAtomIndex, mapPdbAtomIndexToAtomType, graphStartIndexInGspan)

        if graphString != "":
            stringGraphsForConnectedComponent = stringGraphsForConnectedComponent + graphString # concat graphs from one pdbid chain
            outfile = os.path.join(outdir, pdbIdChain + constants.dot + str(graphStartIndexInGspan) + constants.extXml)
            mountGraphmlGraphForOneConnectedComponent(connectedComponent, mapAdjacencyMatrixNodeIndexToGspanNodeIndex,
                                                      gspanEdgeList,
                                                      mapSequentialIndexToPdbAtomIndex, mapPdbAtomIndexToAtomType,
                                                      graphStartIndexInGspan, mapPdbNodeIndexToItsInfo,
                                                      mapStringEdgeTypeToEnglishEdgeType, mapStringEdgeTypeToDistance, outfile)
            graphStartIndexInGspan = graphStartIndexInGspan + 1

    # TODO talvez seja interessante ja retornar o mapeamento para pdb tambem
    #return stringGraphsForConnectedComponent[:-1], graphStartIndexInGspan
    return stringGraphsForConnectedComponent, graphStartIndexInGspan
    # retorna None se deu erro

#TODO quem chama precisa ter o indice do grafo
def mountGraph(connectedComponent, mapAdjacencyMatrixNodeIndexToGspanNodeIndex, gspanEdgeList, mapSequentialIndexToPdbAtomIndex, mapPdbAtomIndexToAtomType, graphStartIndexInGspan):
    stringGraph = "t # " + str(graphStartIndexInGspan) + "\n"
    for i in range (0, len(connectedComponent)):
        gspanNodeIndex = str(mapAdjacencyMatrixNodeIndexToGspanNodeIndex[connectedComponent[i]])
        pdbAtomIndex = str(mapSequentialIndexToPdbAtomIndex[connectedComponent[i]])
        atomType = str(mapPdbAtomIndexToAtomType[pdbAtomIndex])
        stringGraph = stringGraph + "v " + gspanNodeIndex + " " + atomType + "\n"

    for j in range (0, len(gspanEdgeList)):
        temp = gspanEdgeList[j].split(constants.underline)
        sourceNode = str(temp[0])
        targetNode = str(temp[1])
        edgeType = str(temp[2])
        stringGraph = stringGraph + "e " + sourceNode + " " + targetNode + " " + edgeType + "\n"

    return stringGraph

def mountGraphmlGraphForOneConnectedComponent(connectedComponent, mapAdjacencyMatrixNodeIndexToGspanNodeIndex, gspanEdgeList, mapSequentialIndexToPdbAtomIndex,
        mapPdbAtomIndexToAtomType, graphStartIndexInGspan, mapPdbNodeIndexToItsInfo, mapStringEdgeTypeToEnglishEdgeType, mapStringEdgeTypeToDistance, outfile):
    # se precisar imprimir .map, imprimir dentro dessa funcao
    mapGspanNodeIndexToAdjacencyMatrixIndex = {}
    fout = open(outfile, 'w')
    stringGraph = constants.cabecalho + "\n"
    stringGraph = stringGraph + constants.attribute1 + "\n"
    stringGraph = stringGraph + constants.attribute2 + "\n"
    stringGraph = stringGraph + constants.attribute3 + "\n"
    stringGraph = stringGraph + constants.attribute4 + "\n"
    stringGraph = stringGraph + constants.attribute5 + "\n"
    stringGraph = stringGraph + constants.undirectedGraphPart1 + str(graphStartIndexInGspan) + constants.undirectedGraphPart2 + "\n"

    for i in range (0, len(connectedComponent)): # write vertices
        gspanNodeIndex = str(mapAdjacencyMatrixNodeIndexToGspanNodeIndex[connectedComponent[i]])
        pdbAtomIndex = str(mapSequentialIndexToPdbAtomIndex[connectedComponent[i]])
        atomType = str(mapPdbAtomIndexToAtomType[pdbAtomIndex])
        nodeLabel = mapPdbNodeIndexToItsInfo[pdbAtomIndex]
        mapGspanNodeIndexToAdjacencyMatrixIndex[gspanNodeIndex] = connectedComponent[i]

        outLinhaParte1 = "<node id=\"n" + gspanNodeIndex + "\">";
        outLinhaParte2 = "<data key=\"d0\">" + atomType + "</data>";
        outLinhaParte3 = "<data key=\"d2\">" + nodeLabel + "</data>";
        outLinhaParte4 = "</node>";
        stringNode = outLinhaParte1 + "\n" + outLinhaParte2 + "\n" + outLinhaParte3 + "\n" + outLinhaParte4 + "\n"
        stringGraph = stringGraph + stringNode

    for j in range (0, len(gspanEdgeList)): # write edges / gspanEdgeLis = sourceIndex_targetIndex_edgeTypeStringPortuguese
        temp = gspanEdgeList[j].split(constants.underline)
        sourceNode = str(temp[0])
        targetNode = str(temp[1])
        edgeType = str(temp[2])
        edgeString = ""
        contEdge = j

        sourceIndexAdjacencyMatrix = mapGspanNodeIndexToAdjacencyMatrixIndex[sourceNode]
        targetIndexAdjacencyMatrix = mapGspanNodeIndexToAdjacencyMatrixIndex[targetNode]
        sourceIndexPdb = mapSequentialIndexToPdbAtomIndex[sourceIndexAdjacencyMatrix]
        targetIndexPdb = mapSequentialIndexToPdbAtomIndex[targetIndexAdjacencyMatrix]

        # sabrina alterou em 08/06/2016
        edge = ""

        if int(sourceIndexPdb) < int(targetIndexPdb):
            edgeString = sourceIndexPdb + constants.underline + targetIndexPdb
            # sabrina alterou em 08/06/2016
            edge = sourceIndexPdb + constants.underline + targetIndexPdb
        else:
            edgeString = targetIndexPdb + constants.underline + sourceIndexPdb
            # sabrina alterou em 08/06/2016
            edge = targetIndexPdb + constants.underline + sourceIndexPdb

        edgeLabel = mapStringEdgeTypeToEnglishEdgeType[edgeString]

        # TODO rodar e ver se funciona
        # sabrina alterou em 08/06/2016
        distance = mapStringEdgeTypeToDistance[edge]

        outEdgeParte1 = "<edge id=\"e" + str(contEdge) + "\" source=\"n" + sourceNode + "\" target=\"n" + targetNode + "\">";
        outEdgeParte2 = "<data key=\"d1\">" + edgeType + "</data>";
        outEdgeParte3 = "<data key=\"d3\">" + edgeLabel + "</data>";
        outEdgeParte4 = "<data key=\"d4\">" + distance + "</data>";
        outEdgeParte5 = "</edge>";
        stringEdge = outEdgeParte1 + "\n" + outEdgeParte2 + "\n" + outEdgeParte3 + "\n" + outEdgeParte4 + "\n" + outEdgeParte5
        stringGraph = stringGraph + stringEdge + "\n"

    closeGraphml = "</graph>\n</graphml>"
    stringGraph = stringGraph + closeGraphml

    fout.write(stringGraph)
    fout.close()

def changeStringEdgeTypeToEnglishEdgeType(edgeTypeString):
    temp = edgeTypeString.split(constants.slash)
    #numberOfEdgeTypes = len(temp)
    edgeTypeEnglish = ""
    for i in range (0, len(temp)):
        if temp[i] == "aromatico":
            edgeTypeEnglish = edgeTypeEnglish + "AR" + constants.slash
        elif temp[i] == "atrativo":
            edgeTypeEnglish = edgeTypeEnglish + "SB" + constants.slash
        elif temp[i] ==  "ligacaodehidrogenio":
            edgeTypeEnglish = edgeTypeEnglish + "HB" + constants.slash
        elif temp[i] == "hidrofobico":
            edgeTypeEnglish = edgeTypeEnglish + "HP" + constants.slash
        elif temp[i] == "repulsivo":
            edgeTypeEnglish = edgeTypeEnglish + "RP" + constants.slash
        elif temp[i] == "dissulfeto":
            edgeTypeEnglish = edgeTypeEnglish + "DS" + constants.slash
        else:
            print("Encontrou interação não prevista" + edgeTypeString)
    return edgeTypeEnglish[:-1]

def createNogetGenericNameAndDrugnameId(fileWithDrugportIdsWhichMatchToHetGroupsInPDB, outFileGenericNameAndDrugId):
    sepPv = ";"
    sepVirg = ","
    outLine = ""
    haveReadyLine = False
    fout = open(outFileGenericNameAndDrugId, 'w')
    with open(fileWithDrugportIdsWhichMatchToHetGroupsInPDB) as fp:
        for line in fp:
            if haveReadyLine == True:
                fout.write(outLine)
                outLine = ""
            # GENERIC_NAME[1][1] abacavir
            searchObjGenericName = re.search( r'^GENERIC_NAME\[\d+\]\[\d+\]\s+(.+)$', line)
            # DRUGNAME_ID[1][1] DB01048
            searchObjDrugnameId = re.search( r'^DRUGNAME_ID\[\d+\]\[\d+\]\s+(\w+)$', line)
            if searchObjGenericName:
                drugName = searchObjGenericName.group(1).lower()
                outLine += drugName + sepPv
            elif searchObjDrugnameId:
                drugId = searchObjDrugnameId.group(1)
                outLine += drugId + "\n"
                haveReadyLine = True
    fp.close()
    outLine = outLine[:-1]
    fout.write(outLine)
    fout.close()

#-----------------------------------------------------------------------------------------------------------------------

def main(argv):
    atomType = ''
    interactionType = ''
    listOfcontactFile = ''
    try:
        opts, args = getopt.getopt(argv,"ha:i:c:o:",["afile=","ifile=","cfile=","ofile="])
    except getopt.GetoptError:
        print ('gspanGraph.py -a <atomTypeFile> -i <interactionTypeFile> -c <contactFile> -o <outputDir>')
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print ('gspanGraph.py -a <atomTypeFile> -i <interactionTypeFile> -c <contactFile> -o <outputDir>')
            sys.exit()
        elif opt in ("-a", "--afile"):
            atomType = arg
        elif opt in ("-i", "--ifile"):
            interactionType = arg
        elif opt in ("-c", "--cfile"):
            listOfcontactFile = arg
        elif opt in ("-o", "--ofile"):
            outdir = arg

    atomTypeMapping = createAtomOrInteractionTypeMap(atomType)
    interactionTypeMapping = createAtomOrInteractionTypeMap(interactionType)

    outFileGspan = os.path.join(outdir, "inDatasetGraphs.gsp")
    createGspanGraphAndMappingsForListOfCtcFiles(listOfcontactFile, outFileGspan, atomTypeMapping, interactionTypeMapping, outdir)

    print (atomTypeMapping)
    print(interactionTypeMapping)



if __name__ == "__main__":
    main(sys.argv[1:])