/*----------------------------------------
* Depertamento de Informática - UFV
* Charles Abreu Santana - Mat: 87858
* Ultima modificação: 20/04/2016
*-----------------------------------------*/
/* Este programa extrai ligantes de um arquivo PDB. */
#include<iostream>
#include<fstream>
#include<stdio.h>
#include<string>
using namespace std;
//Set eh um vector de string

int main(int argc, char* argv[]){

    if(argc == 1){
        cout<<"Entre com o nome do arquivo como parâmetro!"<<endl;
        return 0;
    }

    string name_file = argv[1];
    ifstream in;
    ofstream saida;
    in.open(name_file.c_str());
    string str;
    string oldChain = " ";

    in >> str;
    while(!in.eof()){
         //Caminho do arquivo .pmapper

        string pdbChain = str.substr(49, 6);
        if(pdbChain.compare(oldChain) != 0){
            string file_name = "outDir/PmapperFiles/" + pdbChain + ".pmapper";

            if(oldChain.compare(" ") != 0){
                saida.close();
            }

            saida.open(file_name.c_str());
            oldChain = pdbChain;
        } else{
            saida <<";";
        }

        ifstream entrada_pmapper(str.c_str());
        char caractere;
        entrada_pmapper >> caractere;
        while(!entrada_pmapper.eof()){
            saida << caractere;
            entrada_pmapper >> caractere;
        }
        in >> str;
    }
    cout << "Done!\n";
}//Fim do main
