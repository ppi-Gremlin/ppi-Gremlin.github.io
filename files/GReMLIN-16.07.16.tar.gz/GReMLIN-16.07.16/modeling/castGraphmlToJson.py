#-----------------------------------------------------------------------
# Structural Bioinformatics Group DPI-Universidade Federal de Vicosa
# Developed by Sabrina Azevedo
# 10/06/2016
#-----------------------------------------------------------------------

import os.path
import getopt
import constants
import re
import sys

def parseListOfGraphml(listOfGraphmlFiles, mapAminoAcids, atomTypeMapping, edgeTypeMapping):
    with open(listOfGraphmlFiles) as fp:
        for line in fp:
            line = line.strip('\n')
            if os.path.isfile(line):
                castGraphmlToJson(line, mapAminoAcids, atomTypeMapping, edgeTypeMapping)
            else:
                print("The file does not exist: ", line);
    fp.close()

def castGraphmlToJson(graphmlFile, mapAminoAcids, atomTypeMapping, edgeTypeMapping):
    searchObjXmlExtension = re.search(r'(.+)\.([A-Za-z])\.(\d+)\.xml$', graphmlFile)
    chain = searchObjXmlExtension.group(2)
    color = constants.colorAminoAcid
    #isLigand = "false"
    contEdge = 0
    if searchObjXmlExtension:
        outfile = searchObjXmlExtension.group(1)+ "." + searchObjXmlExtension.group(2) + "." + searchObjXmlExtension.group(3) + ".graph.json"
        fout = open(outfile, 'w')
        listGraphml = [] # this variable contains the graph in string format. We used a list because string is imutable
        listGraphml.append("{")
        listGraphml.append("\n   \"nodes\" : [")
        with open(graphmlFile) as fp:
            for line in fp:
                line = line.strip('\n')

                searchObjNodeIndex = re.search(r'<node id=\"n(\d+)\">', line)
                if searchObjNodeIndex:
                    listGraphml.append("\n      {")
                    nodeIndex = searchObjNodeIndex.group(1)
                    listGraphml.append("\n         \"index\": " + nodeIndex + constants.sepVirg)
                    listGraphml.append("\n         \"chain\": \"" + chain + "\"" + constants.sepVirg)

                searchObjAtomType = re.search(r'<data key=\"d0\">(\d+)</data>$', line)
                if searchObjAtomType:
                    atomType = searchObjAtomType.group(1)
                    atomTypeStr = castIntToStrAtomType(atomType, atomTypeMapping) # TODO
                    listGraphml.append("\n         \"atomType\" : \"" + atomTypeStr + "\"" + constants.sepVirg)
                    listGraphml.append("\n         \"atomTypeInt\" : \"" + atomType + "\"" + constants.sepVirg)

                #searchObjNodeLabel = re.search(r'<data key=\"d2\">([\w]{3}):(\d+):(\w+)</data>$', line)
                searchObjNodeLabel = re.search(r'<data key=\"d2\">([\w]{3}):(\d+):(.+)</data>$', line)
                if searchObjNodeLabel:
                    residueName = searchObjNodeLabel.group(1)
                    residueNumber = searchObjNodeLabel.group(2)
                    atomName = searchObjNodeLabel.group(3)
                    listGraphml.append("\n         \"atomName\": \"" + atomName + "\"" + constants.sepVirg)
                    listGraphml.append("\n         \"residueNumber\": \"" + residueNumber + "\"" + constants.sepVirg)
                    listGraphml.append("\n         \"residueName\": \"" + residueName + "\"" + constants.sepVirg)

                    if residueName in mapAminoAcids:
                        color = constants.colorAminoAcid
                        isLigand = "false"
                    else:
                        color = constants.colorLigand
                        isLigand = "true"

                    listGraphml.append("\n         \"color\": \"" + color + "\"" + constants.sepVirg)
                    listGraphml.append("\n         \"isLigand\": " + isLigand)
                    listGraphml.append(constants.sepVirg)

                searchObjCloseNode = re.search(r'</node>$', line)
                if searchObjCloseNode:
                    del listGraphml[-1] # remove the last coma from a node
                    listGraphml.append("\n      }")
                    listGraphml.append(",")

                searchObjEdge = re.search(r'.*<edge id=\"e\d+\" source=\"n(\d+)\" target=\"n(\d+)\">$', line)
                if searchObjEdge:
                    contEdge = contEdge + 1
                    if contEdge == 1: ## contEdge ==1 quando acha primeira aresta fecha a secao de nos e abre a de links no json
                        del listGraphml[-1] # remove the coma from last node {,
                        listGraphml.append("\n   ],")
                        listGraphml.append("\n   \"links\" : [")
                    listGraphml.append("\n      {")
                    source = searchObjEdge.group(1)
                    target = searchObjEdge.group(2)
                    listGraphml.append("\n         \"source\" : " + source + constants.sepVirg)
                    listGraphml.append("\n         \"target\" : " + target + constants.sepVirg)

                searchObjEdgeType = re.search(r'<data key=\"d1\">(\d+)</data>$', line)
                if searchObjEdgeType:
                    edgeType = searchObjEdgeType.group(1)
                    edgeTypeStr = castIntToStrEdgeType(edgeType, edgeTypeMapping)
                    listGraphml.append("\n         \"interactionType\" : \"" + edgeTypeStr + "\"" + constants.sepVirg)
                    listGraphml.append("\n         \"interactionTypeInt\" : \"" + edgeType + "\"" + constants.sepVirg)
                    # TODO definir a cor da aresta aqui de acordo com o tipo dela
                    #edgeColor = mapEdgeTypeToColor[edgeType]
                    # listGraphml.append("\n         "\color\" : \"" + edgeColor + "\"")

                # <data key="d1">29</data>

                searchObjEdgeDistance = re.search(r'<data key=\"d4\">(.+)</data>$', line)
                if searchObjEdgeDistance:
                    distance = searchObjEdgeDistance.group(1)
                    listGraphml.append("\n         \"distance\" : \"" + distance + "\"")
                    listGraphml.append(constants.sepVirg)

                searchObjCloseEdge = re.search(r'</edge>.*$', line)
                if searchObjCloseEdge:
                    # TODO tirar virgula do ultimo campo
                    del listGraphml[-1]  # remove the last coma from an edge
                    listGraphml.append("\n      }")
                    listGraphml.append(",")
        del listGraphml[-1]  # remove the coma from last node {,
        listGraphml.append("\n   ]")
        listGraphml.append("\n}")
        strJsonGraph = "".join(listGraphml)
        fp.close()
        #outLine = outLine[:-1]
        fout.write(strJsonGraph)
        fout.close()
    else:
        print("The file is not a .xml: ", graphmlFile);

def createAminoAcidsMap(listOfAminoAcids):
    mapAminoAcids = {}
    with open(listOfAminoAcids) as fp:
        for line in fp:
            aminoAcid = line.strip('\n').upper()
            if aminoAcid not in mapAminoAcids:
                mapAminoAcids[aminoAcid] = 0
    fp.close()
    return mapAminoAcids

def createAtomOrInteractionIntToStrTypeMap(atomOrInteractionTypeFile):
    atomOrInteractionTypeMapping = {}
    with open(atomOrInteractionTypeFile) as fp:
        for line in fp:
            line = line.strip('\n')
            vectorTemp = line.split(constants.sepPv)
            type = vectorTemp[0] # string atom or interaction type
            value = vectorTemp[1] # prime number representing atom or interaction type
            atomOrInteractionTypeMapping[value] = type
    fp.close()
    return atomOrInteractionTypeMapping

def prime_factors(n):
    i = 2
    factors = []
    while i * i <= n:
        if n % i:
            i += 1
        else:
            n //= i
            factors.append(i)
    if n > 1:
        factors.append(n)
    return factors

def castIntToStrAtomType(atomType, atomTypeMapping):
    listOfIntAtomTypes = prime_factors(int(atomType))
    stringAtomType = ""
    for intType in listOfIntAtomTypes:
        stringAtomType = stringAtomType + atomTypeMapping[str(intType)] + "/"
    stringAtomType = stringAtomType[:-1]
    return stringAtomType

def castIntToStrEdgeType(edgeType, edgeTypeMapping):
    listOfIntEdgeTypes = prime_factors(int(edgeType))
    stringEdgeType = ""
    for intType in listOfIntEdgeTypes:
        stringEdgeType =  stringEdgeType + edgeTypeMapping[str(intType)] + "/"
    stringEdgeType = stringEdgeType[:-1]
    return stringEdgeType

#-----------------------------------------------------------------------------------------------------------------------
def main(argv):
    atomType = ''
    interactionType = ''
    listOfAminoAcids = ''
    listOfGraphmlFiles = ''
    try:
        opts, args = getopt.getopt(argv,"ha:i:m:g:",["afile=","ifile=","mfile=","gfile="])
    except getopt.GetoptError:
        print ('castGraphmlToJson.py -a <atomTypeFile> -i <interactionTypeFile> -m<aminoacidsfile> -g <graphfilelist>')
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print ('castGraphmlToJson.py -a <atomTypeFile> -i <interactionTypeFile> -m<aminoacidsfile> -g <graphfilelist>')
            sys.exit()
        elif opt in ("-a", "--afile"):
            atomType = arg
        elif opt in ("-i", "--ifile"):
            interactionType = arg
        elif opt in ("-m", "--mfile"):
            listOfAminoAcids = arg
        elif opt in ("-g", "--gfile"):
            listOfGraphmlFiles = arg

    mapAminoAcids = createAminoAcidsMap(listOfAminoAcids)
    atomTypeMapping = createAtomOrInteractionIntToStrTypeMap(atomType)
    edgeTypeMapping = createAtomOrInteractionIntToStrTypeMap(interactionType)
    parseListOfGraphml(listOfGraphmlFiles, mapAminoAcids, atomTypeMapping, edgeTypeMapping)


if __name__ == "__main__":
    main(sys.argv[1:])
