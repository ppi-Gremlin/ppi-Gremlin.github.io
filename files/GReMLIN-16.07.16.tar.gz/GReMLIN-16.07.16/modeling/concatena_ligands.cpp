/*----------------------------------------
* Depertamento de Informática - UFV
* Charles Abreu Santana - Mat: 87858
* Ultima modificação: 16/05/2016
*-----------------------------------------*/
/* Este programa extrai ligantes de um arquivo PDB. */
#include<iostream>
#include<fstream>
#include<stdio.h>
#include<string>
using namespace std;
//Set eh um vector de string

int main(int argc, char* argv[]){

    if(argc == 1){
        cout<<"Entre com o nome do arquivo como parâmetro!"<<endl;
        return 0;
    }

    string file_name = argv[1];
    ifstream in;
    in.open(file_name.c_str());
    string str;
    int numero_de_ligands;
    string oldChain = " ";
    ofstream saida_by_chain;
    ofstream saida;

    in >> str; //Caminho do arquivo .ligand
    in >> numero_de_ligands; //Quantidade de arquivos .lig
    while(!in.eof()){

        saida.open(str.c_str());

        string pdbChain = str.substr(46,6);
        cout<<pdbChain<<endl;

        if(pdbChain.compare(oldChain) != 0){
            if(oldChain.compare(" ") != 0) saida_by_chain.close();
            string file_name = "outDir/ComputeTrueHetatmToPmapper/fileByLigand/" + pdbChain +".ligand";
            saida_by_chain.open(file_name.c_str());
            oldChain = pdbChain;
        }

        cout<< str <<"\n";

        ifstream entrada_lig;

        for(int i =0; i < numero_de_ligands; i++){
            in >> str;
            entrada_lig.open(str.c_str());
            if(entrada_lig){
                // get length of file:
                entrada_lig.seekg (0, entrada_lig.end);
                long length = entrada_lig.tellg();
                entrada_lig.seekg (0, entrada_lig.beg);

                char * buffer = new char [length];

                // read data as a block:
                entrada_lig.read (buffer,length);
                //write block of data
                saida.write (buffer,length);
                saida_by_chain.write (buffer,length);

                entrada_lig.close();
                delete[] buffer;
            } else{
                cout<<"Arquivo "<< str << "nao encontrado\n";
            }
            /*char linha[512];
            entrada_lig.getline(linha,512);
            while(!entrada_lig.eof()){
                saida << linha << "\n";
                saida_by_chain << linha << "\n";
                entrada_lig.getline(linha,512);
            }
            entrada_lig.close();
            */
        }
        saida.close();
        in >> str; //Caminho do arquivo .ligand
        in >> numero_de_ligands; //Quantidade de arquivos .lig
    }
    saida_by_chain.close();
    cout << "Done!\n";
}//Fim do main
