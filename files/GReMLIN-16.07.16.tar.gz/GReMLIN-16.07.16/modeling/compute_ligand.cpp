/*----------------------------------------
* Depertamento de Informática - UFV
* Charles Abreu Santana - Mat: 87858
* Ultima modificação: 24/02/2016
*-----------------------------------------*/
/* Este programa extrai ligantes de um arquivo PDB. */
#include<iostream>
#include<fstream>
#include<stdio.h>
#include<string>
#include<vector>
#include<sstream>
#include<stdlib.h>
#include <map>

using namespace std;
//Set eh um vector de string
typedef vector <string> Set;

Set insereElemento(Set, string);
bool isIn(Set, string);
Set readArtifactList(string);
void imprimeSet(Set);

int main(int argc, char* argv[]){

    if(argc == 1){
        cout<<"Entre com o nome do arquivo como parâmetro!"<<endl;
        return 0;
    }

    cout << "Iniciando Compute Ligand ...\n";

    string infilePdbIds = argv[1];
    string infileArtifact = argv[2];
    string dirPdbData = argv[3];
    string outDir = argv[4];
    string userArtifactLength = argv[5];

    string nome_do_arquivo;

    nome_do_arquivo = outDir+"/validLigandByChain.csv";
    ofstream outValidLigand(nome_do_arquivo.c_str());
    nome_do_arquivo = outDir+"/invalidLigandByChain.csv";
    ofstream outInvalidLigand(nome_do_arquivo.c_str());
    nome_do_arquivo = outDir+"/artifactLigand.csv";
    ofstream outArtifact(nome_do_arquivo.c_str());
    nome_do_arquivo = outDir+"/nonArtifactLigand.csv";
    ofstream outNonArtifact(nome_do_arquivo.c_str());

    int artifactLength = atoi(userArtifactLength.c_str()); //Converte de string para int

    Set validLigandList; //Lista de ligantes validos
    Set invalidLigandList; //Lista de ligantes invalidos
    Set artifactList; // Lista de Artefatos
    Set nonArtifactList; // Lista de nao Artefatos
    map <string, int> pdbByChain;

    /*
    * Guarda os ligantes encontrados em HET e só considera como ligante em HETATM
    * os que apareceram primeiro em HET. Olhando só o HETATM voltavam algumas águas (HOH),
    * essas aguas nao aparecem em HET
    */
    Set HETligands; // Lista de ligantes encontrados em HET
    Set artifactFromLiterature = readArtifactList(infileArtifact);

    fstream arquivo_pdbids(infilePdbIds.c_str());
    string lineInPdb;
    arquivo_pdbids >> lineInPdb;

    cout<<"Lendo lista de arquivos ...\n";

    while(!arquivo_pdbids.eof()){ // le lista de pdb ids
        int contLigandAtoms = 0;
        string nome_arquivo = dirPdbData + "/" + lineInPdb;
        fstream arquivoPdb(nome_arquivo.c_str());
        string tag, seqNumber;
        char linhaPDBC[256];
        string linhaPDBS, oldLinhaPDB;
        string oldSeqNumber = "";

        arquivoPdb >> tag;
        while(!arquivoPdb.eof()){ // le cada pdb id procurando ligantes
            if(tag.compare("HET") == 0){
                arquivoPdb >> tag;
                HETligands = insereElemento(HETligands,tag); // guarda ligantes encontrados em HET.
                arquivoPdb.ignore(1000, '\n');
            } else if (tag.compare("HETATM") == 0){
                arquivoPdb.getline(linhaPDBC, 256);
                linhaPDBS = linhaPDBC;
                seqNumber = linhaPDBS.substr(16,4);

                if(seqNumber.compare(oldSeqNumber) == 0){
                    contLigandAtoms++;
                } else if(contLigandAtoms == 0){ //Primeira linha do HETATM
                    contLigandAtoms = 1;
                } else{
                    string oldLigandID = oldLinhaPDB.substr(11, 3);
                    string oldChain = oldLinhaPDB.substr(15,1);
                    string oldKey = lineInPdb.substr(0,(lineInPdb.size()-4)) + ":" + oldChain + ";" + oldLigandID;

                    if(isIn(HETligands, oldLigandID)){
                        if((contLigandAtoms >= artifactLength) && (!isIn(artifactFromLiterature,oldLigandID))){
                            if(!isIn(validLigandList, oldKey)){
                                validLigandList = insereElemento(validLigandList, oldKey);
                                outValidLigand << oldKey << "\n";
                                string oldKeyComPonto = oldKey.substr(0,6);
                                oldKeyComPonto[4] = '.';
                                pdbByChain.insert(pair <string, int> (oldKeyComPonto, 0));
                            }
                            if(!isIn(nonArtifactList, oldLigandID)){
                                nonArtifactList = insereElemento(nonArtifactList, oldLigandID);
                                outNonArtifact << oldLigandID << ";" << contLigandAtoms <<"\n";
                            }
                        } else{
                            if(!isIn(invalidLigandList, oldKey)){
                                invalidLigandList = insereElemento(invalidLigandList, oldKey);
                                outInvalidLigand << oldKey << ";" << contLigandAtoms << "\n";
                            }
                            if(!isIn(artifactList,oldLigandID)){
                                artifactList = insereElemento(artifactList, oldLigandID);
                                outArtifact << oldLigandID << ";" << contLigandAtoms <<"\n";
                            }
                        }
                        contLigandAtoms = 1;
                    } // Fim if: se estah contino em HET
                }
                oldSeqNumber = seqNumber;
                oldLinhaPDB = linhaPDBS;
            } else {
                arquivoPdb.ignore(1000, '\n');
            }
            arquivoPdb >> tag;
        }// fim do while: achou o fim de arquivo PBD
        arquivo_pdbids >> lineInPdb;
    }//Fim do while: achou o fim da lista de Arquivos Pdbs
    ofstream ligands_chain("Input/ligands_chain");
    for(map <string, int>::iterator it = pdbByChain.begin(); it != pdbByChain.end(); ++it){
        ligands_chain << it -> first <<"\n";
    }
    ligands_chain.close();
    cout<<"Done!\n";
}//Fim do main


//Insere uma string em uma vector de string
Set insereElemento(Set s, string str){
    if(s.empty()){
        s.push_back(str);
    } else{
        for(int i=0; i < s.size(); i++){
            if(s[i].compare(str) == 0) return s;
        }
        s.push_back(str);
    }
    return s;
}//Fim insere elemento

//Verifica de elemento esta contido no conjunto
bool isIn(Set s, string str){
    if(s.empty()) return false;
    for(int i=0; i < s.size(); i++){
        if(s[i].compare(str) == 0) return true;
    }
    return false;
}//Fim IsIn

Set readArtifactList(string fileName){
    fstream entrada(fileName.c_str());
    string str;
    Set artefatos;
    entrada >> str;
    while(!entrada.eof()){
        artefatos = insereElemento(artefatos, str);
        entrada >> str;
    }//Fim do while
    return artefatos;
}//Fim de readArtifactList

//Funcao auxiliar para imprimir os conjuntos
void imprimeSet(Set s){
    for(int i=0; i<s.size(); i++) cout<<s[i]<<"\n";
}//Fim imprimeSey


