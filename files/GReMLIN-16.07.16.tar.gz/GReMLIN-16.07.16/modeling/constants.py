sepPv = ";"
sepVirg = ","
sepColon = ":"
underline = "_"
slash = "/"
dot = "."
extXml = ".xml"

colorAminoAcid = "#7CB4BE"
colorLigand = "#9BCE91"

sourceAtomIndex = 0
targetAtomIndex = 1

cabecalho = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<graphml xmlns=\"http://graphml.graphdrawing.org/xmlns\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\nxsi:schemaLocation=\"http://graphml.graphdrawing.org/xmlns http://graphml.graphdrawing.org/xmlns/1.0/graphml.xsd\">"
attribute1 = "<key id=\"d0\" for=\"node\" attr.name=\"nodetype\" attr.type=\"int\"/>"
attribute2 = "<key id=\"d1\" for=\"edge\" attr.name=\"edgetype\" attr.type=\"int\"/>"
attribute3 = "<key id=\"d2\" for=\"node\" attr.name=\"nodelabel\" attr.type=\"string\"/>"
attribute4 = "<key id=\"d3\" for=\"edge\" attr.name=\"edgelabel\" attr.type=\"string\"/>"
attribute5 = "<key id=\"d4\" for=\"edge\" attr.name=\"edgeDistance\" attr.type=\"int\"/>"

undirectedGraphPart1 = "<graph id=\"";
undirectedGraphPart2 = "\" edgedefault=\"undirected\">";